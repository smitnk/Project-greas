# Changed Files — Project Grease L2 Vertex Paint + Lasso Selection

## Modified Files (1)

| File | Lines Changed | Description |
|------|---------------|-------------|
| `native/blender_gp/project_grease_gp_jni.cpp` | +37 | Added `Java_com_smitnk_projectgrease_nativebridge_GPNative_nativeToolSamples` JNI wrapper |

### Diff Summary

```diff
+extern "C" JNIEXPORT jint JNICALL
+Java_com_smitnk_projectgrease_nativebridge_GPNative_nativeToolSamples(
+    JNIEnv *env, jobject, jlong handle, jint tool, jfloatArray samples, jint count, jint phase)
+{
+  // Unpacks combined samples+params array from Kotlin ToolSession.pack
+  // Forwards to project_grease_gp_tool_samples bridge function
+  // Returns PG_TOOL_RESULT_* bits
+}
```

---

## Pre-Existing Complete Implementation (Unchanged)

The following files already contained the full Vertex Paint and Lasso Selection implementations. They are included in `SOURCE/` for reference but **require no changes**.

### Vertex Paint (Complete)

| File | Role |
|------|------|
| `native/blender_gp/project_grease_tool_vertex_paint.c` | Verbatim Blender 3.6.23 `gpencil_vertex_paint.c` algorithms |
| `native/blender_gp/project_grease_tool_session.c` | Tool session dispatch for `PG_TOOL_VERTEX_PAINT` |
| `native/blender_gp/project_grease_tool_brushes.h` | `PGToolBrushParams` struct definition |
| `android/.../BlenderSelectRules.kt` | `CMD_VERTEX_PAINT=55`, `vertexPaint()` command builder |
| `android/.../EditorControllers.kt` | `vertexPaintDab()`, `endVertexPaint()`, brush/target/mask state |
| `android/.../FeatureRegistry.kt` | `FeatureId.VERTEX_PAINT` capability (IN_PROGRESS) |
| `android/.../ProjectGreaseUI.kt` | Mode bar, brush/target selectors, palette swatches |

### Lasso Selection (Complete)

| File | Role |
|------|------|
| `native/blender_gp/project_grease_blender_select.c` | Verbatim Blender 3.6.23 `gpencil_select.c` + `select_utils.c` |
| `native/blender_gp/project_grease_gp_bridge.cpp` | `pg_gp_select_dispatch` handles `PG_SELECT_CMD_LASSO=28` |
| `android/.../BlenderSelectRules.kt` | `CMD_LASSO=28`, `lasso()` with eSelectOp/selectmode |
| `android/.../EditorControllers.kt` | `pendingLassoPoints`, live overlay, `endStroke()` submission |
| `android/.../ProjectGreaseUI.kt` | Tool rail entry, live lasso preview overlay |

### Build Configuration (L1 Applied)

| File | Role |
|------|------|
| `tools/android_gp_source_manifest.txt` | Includes `lasso_2d.c`, math, task, eigen, wcwidth, etc. |
| `android/app/src/main/cpp/CMakeLists.txt` | `-funsigned-char`, Eigen, `WITH_SSE2NEON`, sse2neon v1.6.0 |

---

## Test Files (Unchanged)

| File | Role |
|------|------|
| `native/blender_gp/tests/test_tool_session.c` | Vertex paint/sculpt/weight paint conformance tests |
| `native/blender_gp/tests/test_blender_select.c` | Lasso/box/circle selection tests with eSelectOp semantics |

---

## Files NOT Changed (Correctly)

- No changes to `project_grease_gp_bridge.h` (declaration already present)
- No changes to `project_grease_tool_session.h` (constants already defined)
- No changes to Kotlin UI/controller files (already wired to `nativeToolSamples`)
- No changes to Blender algorithm files (verbatim 3.6.23 ports)

---

## Verification

| Check | Result |
|-------|--------|
| JNI wrapper compiles | ✅ |
| Bridge compiles | ✅ |
| Android build | UNVERIFIED (no NDK) |
| Device tests | UNVERIFIED (no device) |