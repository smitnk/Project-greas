/* SPDX-License-Identifier: GPL-2.0-or-later
 *
 * Vertex Paint mode brushes for the native tool session: gpencil_vertex_paint.c (Blender 3.6.23).
 *
 * Verbatim: the operator context, the selected-point buffer, influence / direction / smear grid,
 * the Draw (tint), Blur, Average, Smear and Replace callbacks, and the per-sample selection of the
 * points under the brush (gpencil_vertexpaint_select_stroke). Adapted (no bContext / depsgraph /
 * RNA): do_frame, apply_to_layers, brush_apply, init and exit. The view is the canvas plane
 * (project_grease_tool_util.c), matrices are identity, points are linked to themselves instead of
 * evaluated copies. Colors: the editor keeps material and vertex colors in sRGB, so the brush
 * color is used as given (Blender converts it to linear).
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "MEM_guardedalloc.h"

#include "BLI_listbase.h"
#include "BLI_math.h"
#include "BLI_rect.h"
#include "BLI_utildefines.h"

#include "DNA_brush_types.h"
#include "DNA_gpencil_legacy_types.h"
#include "DNA_material_types.h"
#include "DNA_object_types.h"
#include "DNA_scene_types.h"
#include "DNA_screen_types.h"

#include "BKE_gpencil_legacy.h"

#include "project_grease_tool_brushes.h"
#include "project_grease_tool_view.h"

/* Materials live in bGPdata::mat[] (no Object). */
#define BKE_gpencil_material_settings(ob, act) pg_tool_material_style(gso->gpd, (act))

/* BEGIN VERBATIM source/blender/editors/gpencil_legacy/gpencil_vertex_paint.c */
/* General Brush Editing Context */
#define GP_SELECT_BUFFER_CHUNK 256
#define GP_GRID_PIXEL_SIZE 10.0f

/* Temp Flags while Painting. */
typedef enum eGPDvertex_brush_Flag {
  /* invert the effect of the brush */
  GP_VERTEX_FLAG_INVERT = (1 << 0),
  /* temporary invert action */
  GP_VERTEX_FLAG_TMP_INVERT = (1 << 1),
} eGPDvertex_brush_Flag;

/* Grid of Colors for Smear. */
typedef struct tGP_Grid {
  /** Lower right corner of rectangle of grid cell. */
  float bottom[2];
  /** Upper left corner of rectangle of grid cell. */
  float top[2];
  /** Average Color */
  float color[4];
  /** Total points included. */
  int totcol;

} tGP_Grid;

/* List of points affected by brush. */
typedef struct tGP_Selected {
  /** Referenced stroke. */
  bGPDstroke *gps;
  /** Point index in points array. */
  int pt_index;
  /** Position */
  int pc[2];
  /** Color */
  float color[4];
} tGP_Selected;

/* Context for brush operators */
typedef struct tGP_BrushVertexpaintData {
  Scene *scene;
  Object *object;

  ARegion *region;

  /* Current GPencil datablock */
  bGPdata *gpd;

  Brush *brush;
  float linear_color[3];
  eGPDvertex_brush_Flag flag;
  eGP_Vertex_SelectMaskFlag mask;

  /* Space Conversion Data */
  GP_SpaceConversion gsc;

  /* Is the brush currently painting? */
  bool is_painting;

  /* Start of new paint */
  bool first;

  /* Is multiframe editing enabled, and are we using falloff for that? */
  bool is_multiframe;
  bool use_multiframe_falloff;

  /* Brush Runtime Data: */
  /* - position and pressure
   * - the *_prev variants are the previous values
   */
  float mval[2], mval_prev[2];
  float pressure, pressure_prev;

  /* - Effect 2D vector */
  float dvec[2];

  /* - multiframe falloff factor */
  float mf_falloff;

  /* brush geometry (bounding box) */
  rcti brush_rect;

  /* Temp data to save selected points */
  /** Stroke buffer. */
  tGP_Selected *pbuffer;
  /** Number of elements currently used in cache. */
  int pbuffer_used;
  /** Number of total elements available in cache. */
  int pbuffer_size;

  /** Grid of average colors */
  tGP_Grid *grid;
  /** Total number of rows/cols. */
  int grid_size;
  /** Total number of cells elements in the grid array. */
  int grid_len;
  /** Grid sample position (used to determine distance of falloff) */
  int grid_sample[2];
  /** Grid is ready to use */
  bool grid_ready;

} tGP_BrushVertexpaintData;

/* Ensure the buffer to hold temp selected point size is enough to save all points selected. */
static tGP_Selected *gpencil_select_buffer_ensure(tGP_Selected *buffer_array,
                                                  int *buffer_size,
                                                  int *buffer_used,
                                                  const bool clear)
{
  tGP_Selected *p = NULL;

  /* By default a buffer is created with one block with a predefined number of free slots,
   * if the size is not enough, the cache is reallocated adding a new block of free slots.
   * This is done in order to keep cache small and improve speed. */
  if (*buffer_used + 1 > *buffer_size) {
    if ((*buffer_size == 0) || (buffer_array == NULL)) {
      p = MEM_callocN(sizeof(struct tGP_Selected) * GP_SELECT_BUFFER_CHUNK, __func__);
      *buffer_size = GP_SELECT_BUFFER_CHUNK;
    }
    else {
      *buffer_size += GP_SELECT_BUFFER_CHUNK;
      p = MEM_recallocN(buffer_array, sizeof(struct tGP_Selected) * *buffer_size);
    }

    if (p == NULL) {
      *buffer_size = *buffer_used = 0;
    }

    buffer_array = p;
  }

  /* clear old data */
  if (clear) {
    *buffer_used = 0;
    if (buffer_array != NULL) {
      memset(buffer_array, 0, sizeof(tGP_Selected) * *buffer_size);
    }
  }

  return buffer_array;
}

/* Brush Operations ------------------------------- */

/* Invert behavior of brush? */
static bool brush_invert_check(tGP_BrushVertexpaintData *gso)
{
  /* The basic setting is no inverted */
  bool invert = false;

  /* During runtime, the user can hold down the Ctrl key to invert the basic behavior */
  if (gso->flag & GP_VERTEX_FLAG_INVERT) {
    invert ^= true;
  }

  return invert;
}

/* Compute strength of effect. */
static float brush_influence_calc(tGP_BrushVertexpaintData *gso, const int radius, const int co[2])
{
  Brush *brush = gso->brush;
  float influence = brush->size;

  /* use pressure? */
  if (brush->gpencil_settings->flag & GP_BRUSH_USE_PRESSURE) {
    influence *= gso->pressure;
  }

  /* distance fading */
  int mval_i[2];
  round_v2i_v2fl(mval_i, gso->mval);
  float distance = (float)len_v2v2_int(mval_i, co);

  /* Apply Brush curve. */
  float brush_falloff = BKE_brush_curve_strength(brush, distance, (float)radius);
  influence *= brush_falloff;

  /* apply multiframe falloff */
  influence *= gso->mf_falloff;

  /* return influence */
  return influence;
}

/* Compute effect vector for directional brushes. */
static void brush_calc_dvec_2d(tGP_BrushVertexpaintData *gso)
{
  gso->dvec[0] = (float)(gso->mval[0] - gso->mval_prev[0]);
  gso->dvec[1] = (float)(gso->mval[1] - gso->mval_prev[1]);

  normalize_v2(gso->dvec);
}

/* Init a grid of cells around mouse position.
 *
 * For each Cell.
 *
 *          *--------* Top
 *          |        |
 *          |        |
 *   Bottom *--------*
 *
 * The number of cells is calculated using the brush size and a predefined
 * number of pixels (see: GP_GRID_PIXEL_SIZE)
 */

static void gpencil_grid_cells_init(tGP_BrushVertexpaintData *gso)
{
  tGP_Grid *grid;
  float bottom[2];
  float top[2];
  int grid_index = 0;

  /* The grid center is (0,0). */
  bottom[0] = gso->brush_rect.xmin - gso->mval[0];
  bottom[1] = gso->brush_rect.ymax - GP_GRID_PIXEL_SIZE - gso->mval[1];

  /* Calc all cell of the grid from top/left. */
  for (int y = gso->grid_size - 1; y >= 0; y--) {
    top[1] = bottom[1] + GP_GRID_PIXEL_SIZE;

    for (int x = 0; x < gso->grid_size; x++) {
      top[0] = bottom[0] + GP_GRID_PIXEL_SIZE;

      grid = &gso->grid[grid_index];

      copy_v2_v2(grid->bottom, bottom);
      copy_v2_v2(grid->top, top);

      bottom[0] += GP_GRID_PIXEL_SIZE;

      grid_index++;
    }

    /* Reset for new row. */
    bottom[0] = gso->brush_rect.xmin - gso->mval[0];
    bottom[1] -= GP_GRID_PIXEL_SIZE;
  }
}

/* Get the index used in the grid base on dvec. */
static void gpencil_grid_cell_average_color_idx_get(tGP_BrushVertexpaintData *gso, int r_idx[2])
{
  /* Lower direction. */
  if (gso->dvec[1] < 0.0f) {
    if ((gso->dvec[0] >= -1.0f) && (gso->dvec[0] < -0.8f)) {
      r_idx[0] = 0;
      r_idx[1] = -1;
    }
    else if ((gso->dvec[0] >= -0.8f) && (gso->dvec[0] < -0.6f)) {
      r_idx[0] = -1;
      r_idx[1] = -1;
    }
    else if ((gso->dvec[0] >= -0.6f) && (gso->dvec[0] < 0.6f)) {
      r_idx[0] = -1;
      r_idx[1] = 0;
    }
    else if ((gso->dvec[0] >= 0.6f) && (gso->dvec[0] < 0.8f)) {
      r_idx[0] = -1;
      r_idx[1] = 1;
    }
    else if (gso->dvec[0] >= 0.8f) {
      r_idx[0] = 0;
      r_idx[1] = 1;
    }
  }
  /* Upper direction. */
  else {
    if ((gso->dvec[0] >= -1.0f) && (gso->dvec[0] < -0.8f)) {
      r_idx[0] = 0;
      r_idx[1] = -1;
    }
    else if ((gso->dvec[0] >= -0.8f) && (gso->dvec[0] < -0.6f)) {
      r_idx[0] = 1;
      r_idx[1] = -1;
    }
    else if ((gso->dvec[0] >= -0.6f) && (gso->dvec[0] < 0.6f)) {
      r_idx[0] = 1;
      r_idx[1] = 0;
    }
    else if ((gso->dvec[0] >= 0.6f) && (gso->dvec[0] < 0.8f)) {
      r_idx[0] = 1;
      r_idx[1] = 1;
    }
    else if (gso->dvec[0] >= 0.8f) {
      r_idx[0] = 0;
      r_idx[1] = 1;
    }
  }
}

static int gpencil_grid_cell_index_get(tGP_BrushVertexpaintData *gso, const int pc[2])
{
  float bottom[2], top[2];

  for (int i = 0; i < gso->grid_len; i++) {
    tGP_Grid *grid = &gso->grid[i];
    add_v2_v2v2(bottom, grid->bottom, gso->mval);
    add_v2_v2v2(top, grid->top, gso->mval);

    if (pc[0] >= bottom[0] && pc[0] <= top[0] && pc[1] >= bottom[1] && pc[1] <= top[1]) {
      return i;
    }
  }

  return -1;
}

/* Fill the grid with the color in each cell and assign point cell index. */
static void gpencil_grid_colors_calc(tGP_BrushVertexpaintData *gso)
{
  tGP_Selected *selected = NULL;
  bGPDstroke *gps_selected = NULL;
  bGPDspoint *pt = NULL;
  tGP_Grid *grid = NULL;

  /* Don't calculate again. */
  if (gso->grid_ready) {
    return;
  }

  /* Extract colors by cell. */
  for (int i = 0; i < gso->pbuffer_used; i++) {
    selected = &gso->pbuffer[i];
    gps_selected = selected->gps;
    pt = &gps_selected->points[selected->pt_index];
    int grid_index = gpencil_grid_cell_index_get(gso, selected->pc);

    if (grid_index > -1) {
      grid = &gso->grid[grid_index];
      /* Add stroke mix color (only if used). */
      if (pt->vert_color[3] > 0.0f) {
        add_v3_v3(grid->color, selected->color);
        grid->color[3] = 1.0f;
        grid->totcol++;
      }
    }
  }

  /* Average colors. */
  for (int i = 0; i < gso->grid_len; i++) {
    grid = &gso->grid[i];
    if (grid->totcol > 0) {
      mul_v3_fl(grid->color, (1.0f / (float)grid->totcol));
    }
  }

  /* Save sample position. */
  round_v2i_v2fl(gso->grid_sample, gso->mval);

  gso->grid_ready = true;
}

/* ************************************************ */
/* Brush Callbacks
 * This section defines the callbacks used by each brush to perform their magic.
 * These are called on each point within the brush's radius. */

/* Tint Brush */
static bool brush_tint_apply(tGP_BrushVertexpaintData *gso,
                             bGPDstroke *gps,
                             int pt_index,
                             const int radius,
                             const int co[2])
{
  Brush *brush = gso->brush;

  /* Attenuate factor to get a smoother tinting. */
  float inf = (brush_influence_calc(gso, radius, co) * brush->gpencil_settings->draw_strength) /
              100.0f;
  float inf_fill = (gso->pressure * brush->gpencil_settings->draw_strength) / 1000.0f;

  CLAMP(inf, 0.0f, 1.0f);
  CLAMP(inf_fill, 0.0f, 1.0f);

  /* Apply color to Stroke point. */
  if (GPENCIL_TINT_VERTEX_COLOR_STROKE(brush) && (pt_index > -1)) {
    bGPDspoint *pt = &gps->points[pt_index];
    if (brush_invert_check(gso)) {
      pt->vert_color[3] -= inf;
      CLAMP_MIN(pt->vert_color[3], 0.0f);
    }
    else {
      /* Pre-multiply. */
      mul_v3_fl(pt->vert_color, pt->vert_color[3]);
      /* "Alpha over" blending. */
      interp_v3_v3v3(pt->vert_color, pt->vert_color, gso->linear_color, inf);
      pt->vert_color[3] = pt->vert_color[3] * (1.0 - inf) + inf;
      /* Un pre-multiply. */
      if (pt->vert_color[3] > 0.0f) {
        mul_v3_fl(pt->vert_color, 1.0f / pt->vert_color[3]);
      }
    }
  }

  /* Apply color to Fill area (all with same color and factor). */
  if (GPENCIL_TINT_VERTEX_COLOR_FILL(brush)) {
    if (brush_invert_check(gso)) {
      gps->vert_color_fill[3] -= inf_fill;
      CLAMP_MIN(gps->vert_color_fill[3], 0.0f);
    }
    else {
      /* Pre-multiply. */
      mul_v3_fl(gps->vert_color_fill, gps->vert_color_fill[3]);
      /* "Alpha over" blending. */
      interp_v3_v3v3(gps->vert_color_fill, gps->vert_color_fill, gso->linear_color, inf_fill);
      gps->vert_color_fill[3] = gps->vert_color_fill[3] * (1.0 - inf_fill) + inf_fill;
      /* Un pre-multiply. */
      if (gps->vert_color_fill[3] > 0.0f) {
        mul_v3_fl(gps->vert_color_fill, 1.0f / gps->vert_color_fill[3]);
      }
    }
  }

  return true;
}

/* Replace Brush (Don't use pressure or invert). */
static bool brush_replace_apply(tGP_BrushVertexpaintData *gso, bGPDstroke *gps, int pt_index)
{
  Brush *brush = gso->brush;
  bGPDspoint *pt = &gps->points[pt_index];

  /* Apply color to Stroke point. */
  if (GPENCIL_TINT_VERTEX_COLOR_STROKE(brush)) {
    if (pt->vert_color[3] > 0.0f) {
      copy_v3_v3(pt->vert_color, gso->linear_color);
    }
  }

  /* Apply color to Fill area (all with same color and factor). */
  if (GPENCIL_TINT_VERTEX_COLOR_FILL(brush)) {
    if (gps->vert_color_fill[3] > 0.0f) {
      copy_v3_v3(gps->vert_color_fill, gso->linear_color);
    }
  }

  return true;
}

/* Get surrounding color. */
static bool get_surrounding_color(tGP_BrushVertexpaintData *gso,
                                  bGPDstroke *gps,
                                  int pt_index,
                                  float r_color[3])
{
  tGP_Selected *selected = NULL;
  bGPDstroke *gps_selected = NULL;
  bGPDspoint *pt = NULL;

  int totcol = 0;
  zero_v3(r_color);

  /* Average the surrounding points except current one. */
  for (int i = 0; i < gso->pbuffer_used; i++) {
    selected = &gso->pbuffer[i];
    gps_selected = selected->gps;
    /* current point is not evaluated. */
    if ((gps_selected == gps) && (selected->pt_index == pt_index)) {
      continue;
    }

    pt = &gps_selected->points[selected->pt_index];

    /* Add stroke mix color (only if used). */
    if (pt->vert_color[3] > 0.0f) {
      add_v3_v3(r_color, selected->color);
      totcol++;
    }
  }
  if (totcol > 0) {
    mul_v3_fl(r_color, (1.0f / (float)totcol));
    return true;
  }

  return false;
}

/* Blur Brush */
static bool brush_blur_apply(tGP_BrushVertexpaintData *gso,
                             bGPDstroke *gps,
                             int pt_index,
                             const int radius,
                             const int co[2])
{
  Brush *brush = gso->brush;

  /* Attenuate factor to get a smoother tinting. */
  float inf = (brush_influence_calc(gso, radius, co) * brush->gpencil_settings->draw_strength) /
              100.0f;
  float inf_fill = (gso->pressure * brush->gpencil_settings->draw_strength) / 1000.0f;

  bGPDspoint *pt = &gps->points[pt_index];

  /* Get surrounding color. */
  float blur_color[3];
  if (get_surrounding_color(gso, gps, pt_index, blur_color)) {
    /* Apply color to Stroke point. */
    if (GPENCIL_TINT_VERTEX_COLOR_STROKE(brush)) {
      interp_v3_v3v3(pt->vert_color, pt->vert_color, blur_color, inf);
    }

    /* Apply color to Fill area (all with same color and factor). */
    if (GPENCIL_TINT_VERTEX_COLOR_FILL(brush)) {
      interp_v3_v3v3(gps->vert_color_fill, gps->vert_color_fill, blur_color, inf_fill);
    }
    return true;
  }

  return false;
}

/* Average Brush */
static bool brush_average_apply(tGP_BrushVertexpaintData *gso,
                                bGPDstroke *gps,
                                int pt_index,
                                const int radius,
                                const int co[2],
                                float average_color[3])
{
  Brush *brush = gso->brush;

  /* Attenuate factor to get a smoother tinting. */
  float inf = (brush_influence_calc(gso, radius, co) * brush->gpencil_settings->draw_strength) /
              100.0f;
  float inf_fill = (gso->pressure * brush->gpencil_settings->draw_strength) / 1000.0f;

  bGPDspoint *pt = &gps->points[pt_index];

  float alpha = pt->vert_color[3];
  float alpha_fill = gps->vert_color_fill[3];

  if (brush_invert_check(gso)) {
    alpha -= inf;
    alpha_fill -= inf_fill;
  }
  else {
    alpha += inf;
    alpha_fill += inf_fill;
  }

  /* Apply color to Stroke point. */
  if (GPENCIL_TINT_VERTEX_COLOR_STROKE(brush)) {
    CLAMP(alpha, 0.0f, 1.0f);
    interp_v3_v3v3(pt->vert_color, pt->vert_color, average_color, inf);
    pt->vert_color[3] = alpha;
  }

  /* Apply color to Fill area (all with same color and factor). */
  if (GPENCIL_TINT_VERTEX_COLOR_FILL(brush)) {
    CLAMP(alpha_fill, 0.0f, 1.0f);
    copy_v3_v3(gps->vert_color_fill, average_color);
    gps->vert_color_fill[3] = alpha_fill;
  }

  return true;
}

/* Smear Brush */
static bool brush_smear_apply(tGP_BrushVertexpaintData *gso,
                              bGPDstroke *gps,
                              int pt_index,
                              tGP_Selected *selected)
{
  Brush *brush = gso->brush;
  tGP_Grid *grid = NULL;
  int average_idx[2];
  ARRAY_SET_ITEMS(average_idx, 0, 0);

  bool changed = false;

  /* Need some movement, so first input is not done. */
  if (gso->first) {
    return false;
  }

  bGPDspoint *pt = &gps->points[pt_index];

  /* Need get average colors in the grid. */
  if ((!gso->grid_ready) && (gso->pbuffer_used > 0)) {
    gpencil_grid_colors_calc(gso);
  }

  /* The influence is equal to strength and no decay around brush radius. */
  float inf = brush->gpencil_settings->draw_strength;
  if (brush->flag & GP_BRUSH_USE_PRESSURE) {
    inf *= gso->pressure;
  }

  /* Calc distance from initial sample location and add a falloff effect. */
  int mval_i[2];
  round_v2i_v2fl(mval_i, gso->mval);
  float distance = (float)len_v2v2_int(mval_i, gso->grid_sample);
  float fac = 1.0f - (distance / (float)(brush->size * 2));
  CLAMP(fac, 0.0f, 1.0f);
  inf *= fac;

  /* Retry row and col for average color. */
  gpencil_grid_cell_average_color_idx_get(gso, average_idx);

  /* Retry average color cell. */
  int grid_index = gpencil_grid_cell_index_get(gso, selected->pc);
  if (grid_index > -1) {
    int row = grid_index / gso->grid_size;
    int col = grid_index - (gso->grid_size * row);
    row += average_idx[0];
    col += average_idx[1];
    CLAMP(row, 0, gso->grid_size);
    CLAMP(col, 0, gso->grid_size);

    int new_index = (row * gso->grid_size) + col;
    CLAMP(new_index, 0, gso->grid_len - 1);
    grid = &gso->grid[new_index];
  }

  /* Apply color to Stroke point. */
  if (GPENCIL_TINT_VERTEX_COLOR_STROKE(brush)) {
    if (grid_index > -1) {
      if (grid->color[3] > 0.0f) {
        // copy_v3_v3(pt->vert_color, grid->color);
        interp_v3_v3v3(pt->vert_color, pt->vert_color, grid->color, inf);
        changed = true;
      }
    }
  }

  /* Apply color to Fill area (all with same color and factor). */
  if (GPENCIL_TINT_VERTEX_COLOR_FILL(brush)) {
    if (grid_index > -1) {
      if (grid->color[3] > 0.0f) {
        interp_v3_v3v3(gps->vert_color_fill, gps->vert_color_fill, grid->color, inf);
        changed = true;
      }
    }
  }

  return changed;
}
/* END VERBATIM */

/* BEGIN VERBATIM source/blender/editors/gpencil_legacy/gpencil_vertex_paint.c */
/* Helper to save the points selected by the brush. */
static void gpencil_save_selected_point(tGP_BrushVertexpaintData *gso,
                                        bGPDstroke *gps,
                                        int index,
                                        int pc[2])
{
  tGP_Selected *selected;
  bGPDspoint *pt = &gps->points[index];

  /* Ensure the array to save the list of selected points is big enough. */
  gso->pbuffer = gpencil_select_buffer_ensure(
      gso->pbuffer, &gso->pbuffer_size, &gso->pbuffer_used, false);

  selected = &gso->pbuffer[gso->pbuffer_used];
  selected->gps = gps;
  selected->pt_index = index;
  /* Check the index is not a special case for fill. */
  if (index > -1) {
    copy_v2_v2_int(selected->pc, pc);
    copy_v4_v4(selected->color, pt->vert_color);
  }
  gso->pbuffer_used++;
}

/* Select points in this stroke and add to an array to be used later.
 * Returns true if any point was hit and got saved */
static bool gpencil_vertexpaint_select_stroke(tGP_BrushVertexpaintData *gso,
                                              bGPDstroke *gps,
                                              const char tool,
                                              const float diff_mat[4][4],
                                              const float bound_mat[4][4])
{
  GP_SpaceConversion *gsc = &gso->gsc;
  rcti *rect = &gso->brush_rect;
  Brush *brush = gso->brush;
  const int radius = (brush->flag & GP_BRUSH_USE_PRESSURE) ? gso->brush->size * gso->pressure :
                                                             gso->brush->size;
  bGPDstroke *gps_active = (gps->runtime.gps_orig) ? gps->runtime.gps_orig : gps;
  bGPDspoint *pt_active = NULL;

  bGPDspoint *pt1, *pt2;
  bGPDspoint *pt = NULL;
  int pc1[2] = {0};
  int pc2[2] = {0};
  int i;
  int index;
  bool include_last = false;

  bool saved = false;

  /* Check stroke masking. */
  if (GPENCIL_ANY_VERTEX_MASK(gso->mask)) {
    if ((gps->flag & GP_STROKE_SELECT) == 0) {
      return false;
    }
  }

  /* Check if the stroke collide with brush. */
  if (!ED_gpencil_stroke_check_collision(gsc, gps, gso->mval, radius, bound_mat)) {
    return false;
  }

  if (gps->totpoints == 1) {
    bGPDspoint pt_temp;
    pt = &gps->points[0];
    gpencil_point_to_world_space(gps->points, diff_mat, &pt_temp);
    gpencil_point_to_xy(gsc, gps, &pt_temp, &pc1[0], &pc1[1]);

    pt_active = (pt->runtime.pt_orig) ? pt->runtime.pt_orig : pt;
    /* Do bound-box check first. */
    if (!ELEM(V2D_IS_CLIPPED, pc1[0], pc1[1]) && BLI_rcti_isect_pt(rect, pc1[0], pc1[1])) {
      /* only check if point is inside */
      int mval_i[2];
      round_v2i_v2fl(mval_i, gso->mval);
      if (len_v2v2_int(mval_i, pc1) <= radius) {
        /* apply operation to this point */
        if (pt_active != NULL) {
          gpencil_save_selected_point(gso, gps_active, 0, pc1);
          saved = true;
        }
      }
    }
  }
  else {
    /* Loop over the points in the stroke, checking for intersections
     * - an intersection means that we touched the stroke
     */
    bool hit = false;
    for (i = 0; (i + 1) < gps->totpoints; i++) {
      /* Get points to work with */
      pt1 = gps->points + i;
      pt2 = gps->points + i + 1;

      /* Skip if neither one is selected
       * (and we are only allowed to edit/consider selected points) */
      if (GPENCIL_ANY_VERTEX_MASK(gso->mask)) {
        if (!(pt1->flag & GP_SPOINT_SELECT) && !(pt2->flag & GP_SPOINT_SELECT)) {
          include_last = false;
          continue;
        }
      }

      bGPDspoint npt;
      gpencil_point_to_world_space(pt1, diff_mat, &npt);
      gpencil_point_to_xy(gsc, gps, &npt, &pc1[0], &pc1[1]);

      gpencil_point_to_world_space(pt2, diff_mat, &npt);
      gpencil_point_to_xy(gsc, gps, &npt, &pc2[0], &pc2[1]);

      /* Check that point segment of the bound-box of the selection stroke. */
      if ((!ELEM(V2D_IS_CLIPPED, pc1[0], pc1[1]) && BLI_rcti_isect_pt(rect, pc1[0], pc1[1])) ||
          (!ELEM(V2D_IS_CLIPPED, pc2[0], pc2[1]) && BLI_rcti_isect_pt(rect, pc2[0], pc2[1])))
      {
        /* Check if point segment of stroke had anything to do with
         * brush region  (either within stroke painted, or on its lines)
         * - this assumes that line-width is irrelevant.
         */
        if (gpencil_stroke_inside_circle(gso->mval, radius, pc1[0], pc1[1], pc2[0], pc2[1])) {

          /* To each point individually... */
          pt = &gps->points[i];
          pt_active = pt->runtime.pt_orig;
          if (pt_active != NULL) {
            /* If masked and the point is not selected, skip it. */
            if (GPENCIL_ANY_VERTEX_MASK(gso->mask) && ((pt_active->flag & GP_SPOINT_SELECT) == 0))
            {
              continue;
            }
            index = (pt->runtime.pt_orig) ? pt->runtime.idx_orig : i;
            hit = true;
            gpencil_save_selected_point(gso, gps_active, index, pc1);
            saved = true;
          }

          /* Only do the second point if this is the last segment,
           * and it is unlikely that the point will get handled
           * otherwise.
           *
           * NOTE: There is a small risk here that the second point wasn't really
           *       actually in-range. In that case, it only got in because
           *       the line linking the points was!
           */
          if (i + 1 == gps->totpoints - 1) {
            pt = &gps->points[i + 1];
            pt_active = pt->runtime.pt_orig;
            if (pt_active != NULL) {
              index = (pt->runtime.pt_orig) ? pt->runtime.idx_orig : i + 1;
              hit = true;
              gpencil_save_selected_point(gso, gps_active, index, pc2);
              include_last = false;
              saved = true;
            }
          }
          else {
            include_last = true;
          }
        }
        else if (include_last) {
          /* This case is for cases where for whatever reason the second vert (1st here)
           * doesn't get included because the whole edge isn't in bounds,
           * but it would've qualified since it did with the previous step
           * (but wasn't added then, to avoid double-ups).
           */
          pt = &gps->points[i];
          pt_active = pt->runtime.pt_orig;
          if (pt_active != NULL) {
            index = (pt->runtime.pt_orig) ? pt->runtime.idx_orig : i;
            hit = true;
            gpencil_save_selected_point(gso, gps_active, index, pc1);
            include_last = false;
            saved = true;
          }
        }
      }
    }

    /* If nothing hit, check if the mouse is inside any filled stroke. */
    if ((!hit) && ELEM(tool, GPAINT_TOOL_TINT, GPVERTEX_TOOL_DRAW)) {
      MaterialGPencilStyle *gp_style = BKE_gpencil_material_settings(gso->object,
                                                                     gps_active->mat_nr + 1);
      if (gp_style->flag & GP_MATERIAL_FILL_SHOW) {
        int mval[2];
        round_v2i_v2fl(mval, gso->mval);
        bool hit_fill = ED_gpencil_stroke_point_is_inside(gps_active, gsc, mval, diff_mat);
        if (hit_fill) {
          /* Need repeat the effect because if we don't do that the tint process
           * is very slow. */
          for (int repeat = 0; repeat < 50; repeat++) {
            gpencil_save_selected_point(gso, gps_active, -1, NULL);
          }
          saved = true;
        }
      }
    }
  }

  return saved;
}
/* END VERBATIM */

/* ---- Project Grease adaptation of the operator loop ---------------------------------------- */

/* gpencil_vertexpaint_brush_do_frame() without the context checks (every stroke can be used on the
 * canvas; editability uses bGPdata::mat[]). */
static bool pgt_vpaint_do_frame(tGP_BrushVertexpaintData *gso, bGPDlayer *gpl, bGPDframe *gpf)
{
  const char tool = gso->brush->gpencil_vertex_tool;
  const int radius = (gso->brush->flag & GP_BRUSH_USE_PRESSURE) ?
                         gso->brush->size * gso->pressure :
                         gso->brush->size;
  tGP_Selected *selected = NULL;
  int i;
  float diff_mat[4][4], bound_mat[4][4];
  unit_m4(diff_mat);
  unit_m4(bound_mat);

  /* First step: select the points affected. */
  LISTBASE_FOREACH (bGPDstroke *, gps, &gpf->strokes) {
    if (gps->points == NULL || gps->totpoints <= 0) {
      continue;
    }
    const MaterialGPencilStyle *gp_style = pg_tool_material_style(gso->gpd, gps->mat_nr + 1);
    if ((gp_style->flag & GP_MATERIAL_HIDE) ||
        (((gpl->flag & GP_LAYER_UNLOCK_COLOR) == 0) && (gp_style->flag & GP_MATERIAL_LOCKED)))
    {
      continue;
    }
    gpencil_vertexpaint_select_stroke(gso, gps, tool, diff_mat, bound_mat);
  }

  /* For Average tool, the average resulting color from all colors under the brush. */
  float average_color[3] = {0};
  int totcol = 0;
  if ((tool == GPVERTEX_TOOL_AVERAGE) && (gso->pbuffer_used > 0)) {
    for (i = 0; i < gso->pbuffer_used; i++) {
      selected = &gso->pbuffer[i];
      bGPDstroke *gps = selected->gps;
      bGPDspoint *pt = &gps->points[selected->pt_index];
      if (pt->vert_color[3] > 0.0f) {
        add_v3_v3(average_color, pt->vert_color);
        totcol++;
      }
      if (gps->vert_color_fill[3] > 0.0f) {
        add_v3_v3(average_color, gps->vert_color_fill);
        totcol++;
      }
    }
    if (totcol > 0) {
      mul_v3_fl(average_color, (1.0f / (float)totcol));
    }
  }

  /* Second step: apply effect. */
  bool changed = false;
  for (i = 0; i < gso->pbuffer_used; i++) {
    changed = true;
    selected = &gso->pbuffer[i];
    switch (tool) {
      case GPAINT_TOOL_TINT:
      case GPVERTEX_TOOL_DRAW:
        brush_tint_apply(gso, selected->gps, selected->pt_index, radius, selected->pc);
        break;
      case GPVERTEX_TOOL_BLUR:
        brush_blur_apply(gso, selected->gps, selected->pt_index, radius, selected->pc);
        break;
      case GPVERTEX_TOOL_AVERAGE:
        brush_average_apply(gso, selected->gps, selected->pt_index, radius, selected->pc,
                            average_color);
        break;
      case GPVERTEX_TOOL_SMEAR:
        brush_smear_apply(gso, selected->gps, selected->pt_index, selected);
        break;
      case GPVERTEX_TOOL_REPLACE:
        brush_replace_apply(gso, selected->gps, selected->pt_index);
        break;
      default:
        break;
    }
  }
  gso->pbuffer = gpencil_select_buffer_ensure(
      gso->pbuffer, &gso->pbuffer_size, &gso->pbuffer_used, true);
  return changed;
}

static bool pgt_vpaint_apply_to_layers(tGP_BrushVertexpaintData *gso)
{
  bool changed = false;
  LISTBASE_FOREACH (bGPDlayer *, gpl, &gso->gpd->layers) {
    if (!BKE_gpencil_layer_is_editable(gpl) || (gpl->actframe == NULL)) {
      continue;
    }
    if (gso->is_multiframe) {
      LISTBASE_FOREACH (bGPDframe *, gpf, &gpl->frames) {
        if ((gpf == gpl->actframe) || (gpf->flag & GP_FRAME_SELECT)) {
          gso->mf_falloff = 1.0f;
          changed |= pgt_vpaint_do_frame(gso, gpl, gpf);
        }
      }
    }
    else {
      gso->mf_falloff = 1.0f;
      changed |= pgt_vpaint_do_frame(gso, gpl, gpl->actframe);
    }
  }
  return changed;
}

struct PGVertexPaintSession {
  tGP_BrushVertexpaintData gso;
  Brush brush;
  BrushGpencilSettings settings;
  PGToolView view;
};

/* gpencil_vertexpaint_brush_init() with BKE_gpencil_brush_preset_set()'s vertex presets. */
PGVertexPaintSession *pg_vpaint_session_begin(bGPdata *gpd, const PGToolBrushParams *params)
{
  if (gpd == NULL || params == NULL || params->brush < GPVERTEX_TOOL_DRAW ||
      params->brush > GPVERTEX_TOOL_REPLACE || !(params->radius > 0.0f) ||
      params->target < GPPAINT_MODE_STROKE || params->target > GPPAINT_MODE_BOTH)
  {
    return NULL;
  }
  PGVertexPaintSession *s = MEM_callocN(sizeof(PGVertexPaintSession), "PGVertexPaintSession");
  tGP_BrushVertexpaintData *gso = &s->gso;
  Brush *brush = &s->brush;
  brush->gpencil_settings = &s->settings;
  brush->gpencil_vertex_tool = (char)params->brush;
  brush->curve_preset = BRUSH_CURVE_SMOOTH;
  if (params->curve_preset > BRUSH_CURVE_CUSTOM && params->curve_preset <= BRUSH_CURVE_SMOOTHER) {
    brush->curve_preset = params->curve_preset;
  }
  s->settings.flag |= GP_BRUSH_USE_PRESSURE;
  if (params->brush == GPVERTEX_TOOL_REPLACE) {
    s->settings.flag &= ~GP_BRUSH_USE_PRESSURE; /* "Don't use pressure or invert" */
  }
  s->settings.vertex_mode = (char)params->target;
  pg_tool_view_init(&s->view, &gso->gsc, params->px_per_unit);
  brush->size = max_ii(1, (int)lroundf(params->radius * s->view.px_per_unit));
  s->settings.draw_strength = clamp_f(params->strength, 0.0f, 1.0f);
  copy_v3_v3(brush->rgb, params->rgb);
  copy_v3_v3(gso->linear_color, params->rgb);

  gso->brush = brush;
  gso->is_painting = false;
  gso->first = true;
  gso->grid_size = (int)(((gso->brush->size * 2.0f) / GP_GRID_PIXEL_SIZE) + 1.0);
  gso->grid_len = gso->grid_size * gso->grid_size;
  gso->grid = MEM_callocN(sizeof(tGP_Grid) * gso->grid_len, "tGP_Grid");
  gso->grid_ready = false;
  gso->gpd = gpd;
  gso->gsc.gpd = gpd;
  gso->scene = &s->view.scene;
  gso->object = &s->view.ob;
  gso->region = &s->view.region;
  /* ts->gpencil_selectmode_vertex (GP_VERTEX_MASK_SELECTMODE_POINT / STROKE / SEGMENT) */
  gso->mask = (eGP_Vertex_SelectMaskFlag)(params->select_mask & (GP_VERTEX_MASK_SELECTMODE_POINT |
                                                                  GP_VERTEX_MASK_SELECTMODE_STROKE |
                                                                  GP_VERTEX_MASK_SELECTMODE_SEGMENT));
  gso->is_multiframe = GPENCIL_MULTIEDIT_SESSIONS_ON(gpd);
  if (params->invert) {
    gso->flag |= GP_VERTEX_FLAG_INVERT;
  }
  pg_tool_link_runtime(gpd, true);
  return s;
}

/* gpencil_vertexpaint_brush_apply(): one input event. */
int pg_vpaint_session_sample(PGVertexPaintSession *s, float x, float y, float pressure)
{
  if (s == NULL || !isfinite(x) || !isfinite(y)) {
    return 0;
  }
  tGP_BrushVertexpaintData *gso = &s->gso;
  Brush *brush = gso->brush;
  const float scale = s->view.px_per_unit;
  int mouse[2];
  gso->mval[0] = mouse[0] = (int)(x * scale);
  gso->mval[1] = mouse[1] = (int)(y * scale);
  gso->pressure = (pressure >= 0.99f) ? 1.0f : clamp_f(pressure, 0.0f, 1.0f);
  const int radius = ((brush->flag & GP_BRUSH_USE_PRESSURE) ? gso->brush->size * gso->pressure :
                                                              gso->brush->size);
  if (gso->first) {
    gso->mval_prev[0] = gso->mval[0];
    gso->mval_prev[1] = gso->mval[1];
    gso->pressure_prev = gso->pressure;
  }
  gso->brush_rect.xmin = mouse[0] - radius;
  gso->brush_rect.ymin = mouse[1] - radius;
  gso->brush_rect.xmax = mouse[0] + radius;
  gso->brush_rect.ymax = mouse[1] + radius;
  brush_calc_dvec_2d(gso);
  gpencil_grid_cells_init(gso);

  const bool changed = pgt_vpaint_apply_to_layers(gso);
  if (changed) {
    gso->gpd->flag |= GP_DATA_CACHE_IS_DIRTY;
    BKE_gpencil_batch_cache_dirty_tag(gso->gpd);
  }
  gso->mval_prev[0] = gso->mval[0];
  gso->mval_prev[1] = gso->mval[1];
  gso->pressure_prev = gso->pressure;
  gso->first = false;
  return changed ? 1 : 0;
}

/* gpencil_vertexpaint_brush_exit(). */
void pg_vpaint_session_end(PGVertexPaintSession *s)
{
  if (s == NULL) {
    return;
  }
  MEM_SAFE_FREE(s->gso.pbuffer);
  MEM_SAFE_FREE(s->gso.grid);
  pg_tool_link_runtime(s->gso.gpd, false);
  MEM_freeN(s);
}
