# Project Grease L2 — Vertex Paint + Lasso Selection (FIXED)

This package contains the **actual code fix** for enabling Vertex Paint and Lasso Selection in Project Grease.

## The Fix

**Single JNI wrapper addition** in `native/blender_gp/project_grease_gp_jni.cpp`:

```cpp
Java_com_smitnk_projectgrease_nativebridge_GPNative_nativeToolSamples
```

This enables the native tool session (`project_grease_tool_session.c`) which implements all four Blender 3.6.23 Legacy GP brush tools:
- `PG_TOOL_DRAW` — gpencil_paint.c input pipeline
- `PG_TOOL_SCULPT` — gpencil_sculpt_paint.c brushes
- `PG_TOOL_VERTEX_PAINT` — gpencil_vertex_paint.c brushes (Draw, Blur, Average, Smear, Replace)
- `PG_TOOL_WEIGHT_PAINT` — gpencil_weight_paint.c brushes

## Lasso Selection

Already functional via edit command path (`CMD_LASSO=28` → `pg_gp_select_dispatch` → `pg_gp_select_lasso`) using full Blender 3.6.23 selection semantics (eSelectOp: SET/ADD/SUB/AND/XOR, select modes: POINT/STROKE).

## Contents

```
Project-Grease-L2-VertexPaint-Lasso-FIXED/
├── README.md
├── L2_IMPLEMENTATION_REPORT.md
├── CHANGED_FILES.md
├── BASE_REVISION.txt
├── PATCHES/
│   └── 0001-Add-JNI-wrapper-for-nativeToolSamples.patch
├── SOURCE/
│   ├── project_grease_gp_jni.cpp          (MODIFIED)
│   ├── project_grease_tool_vertex_paint.c
│   ├── project_grease_blender_select.c
│   ├── project_grease_tool_session.c
│   ├── project_grease_gp_bridge.cpp
│   ├── BlenderSelectRules.kt
│   ├── EditorControllers.kt
│   └── android_gp_source_manifest.txt
├── TESTS/
│   ├── test_tool_session.c
│   └── test_blender_select.c
└── EVIDENCE/
    └── (key source files for review)
```

## Base Revision

- **Project Grease**: `feature/project-grease-ui-real-integration` at `e780ef27dc8350709407ef22a80543be0bcc5be6`
- **Blender Source**: `e467db79ca8cc5c1c15e1a0e08bd52ca419f2eca` (Blender 3.6.23)
- **L1 Package**: Applied (manifest includes BLI closure)

## Verification Status

| Component | Status |
|-----------|--------|
| JNI wrapper compilation | ✅ PASS |
| Bridge compilation | ✅ PASS |
| Android build | **UNVERIFIED** (no NDK) |
| Device tests | **UNVERIFIED** (no device/emulator) |
| Host unit tests | **UNVERIFIED** (linker gaps in minimal test harness) |

## Applying the Fix

```bash
git apply PATCHES/0001-Add-JNI-wrapper-for-nativeToolSamples.patch
# Build with Android NDK r25+
# Test on device
```

## No Git Operations

No commits, pushes, or CI runs performed.