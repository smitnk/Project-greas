# Project Grease L2–L4 package (Blender 3.6.23, 2D Grease Pencil scope)

Base: `feature/l1-implementation` @ `56c18d9` (PR #50 head, CI green). Blender `e467db79` (v3.6.23).
Scope: Blender 2D Grease Pencil only. Shrinkwrap, Armature and 3D mesh evaluation are excluded.
Nothing was committed or pushed.

## L2: external libraries (D1 = B, .blend reader only)
- `curve_fit_nd` (REQUIRED) was already in the Android manifest; it is unchanged.
- **zstd 1.5.0 and zlib 1.2.13**, the exact versions Blender pins in
  `build_files/build_environment/cmake/versions.cmake`. `tools/import_blender_gp.sh` fetches them and
  checks Blender's own hashes (zstd SHA-256 `5194fbfa…`, zlib MD5 `9b8aa094…`). A wrong hash aborts the
  import (tested). Only **decompression** sources go into the manifest.
- Blender's reader layer, verbatim: `filereader_file/gzip/zstd/memory.c`, `BLI_mmap.c`, `storage.c`
  (`BLI_lseek`), `fileops.c` (`BLI_file_magic_is_gzip/zstd`).
- Blender platform defines `_LARGEFILE_SOURCE _FILE_OFFSET_BITS=64 _LARGEFILE64_SOURCE`
  (platform_unix.cmake:575) were added to the Android target and the link probe.
- Writer and compressor are excluded (D1 = B). The reader-only closure links with both GNU ld and lld
  without any compressor object; the unused compress references in `fileops.c` are garbage-collected.
- Test `tools/run_native_filereader_tests.sh`:
  - Fixtures: zstd written exactly as `writefile.cc` writes it (1 MiB frames, level 3, seek table), a
    zstd file without a seek table, and gzip.
  - Checks: full reads, random seeks, `SEEK_END`, rejection of a seek past the end, Blender's magic
    sniffing, and the mmap, memory and file readers.
- Evidence for the platform flags: `BLI_file_magic_is_gzip` gives the wrong answer without Blender's
  `-funsigned-char`, because it compares a `char` with `0x8b`. The L2 objects are therefore built with
  Blender's Unix flags.

## L3: DNA defaults
- Blender's `makesdna/intern/dna_defaults.c` (`DNA_struct_default_get`) and the data it references
  (`release/datafiles/userdef/userdef_default.c`, `userdef_default_theme.c`), all verbatim, are in the
  manifest. They compile against PG's generated DNA.
- Test `tools/run_native_dna_defaults_tests.sh` checks **129 PG default values** against Blender's
  table: all match.
- 11 groups are listed as NOT COMPARED, each with its reason. These are PG 2D adaptations: canvas
  pixels or a canvas point instead of an object.
- Hook falloff is compared by meaning. PG's 2D hook encodes it as 0 none / 1 smooth / 2 linear; PG's
  smooth is the same `3t²−2t³` as Blender's `eGPHook_Falloff_Smooth`.
- A mutation check (Noise factor changed from 0.5 to 0.4) makes the test fail, so it is not vacuous.

## L4: RNA property layer (PLATFORM REPLACE)
- **The table comes from Blender's own code**, not from a transcription.
  - `tools/rna_ranges/pg_rna_dump.c` runs Blender's real `RNA_def_rna`, `RNA_def_ID`,
    `RNA_def_gpencil`, `RNA_def_greasepencil_modifier` and `RNA_def_shader_fx`, in `makesrna`'s
    preprocess mode and order, through the real `rna_define.c`. It then dumps what `rna_define.c`
    stored.
  - `gen_rna_table.py` turns the dump into `native/blender_gp/rna/project_grease_rna_gen.c`:
    709 properties, with Shrinkwrap and Armature excluded.
  - CI regenerates the table and fails on any difference.
- `project_grease_rna.c`:
  - Lookup and enum validity helpers.
  - The generated-setter clamp (`makesrna.c rna_clamp_value`: `CLAMPIS` to the hard range).
  - Blender's custom functions **verbatim** (`verify_blender_verbatim.py`: 101/101 regions pass):
    `rna_GpencilOpacity_range/max_set`, `rna_TimeModifier_start/end_frame_set`,
    `rna_Lineart_start/end_level_set`.
- **The PG limits are fixed.**
  - The test showed PG's hand-written clamps differed from Blender's RNA for most mapped parameters.
    Examples: Thickness 0..32767 vs Blender −100..500; Noise factor ≤1 vs Blender ≥0; Smooth factor ≤2
    vs ≤1; Weight Angle ±2π vs 0..π; Time mode rejected Blender's item 4.
  - Fix: `pg_mod_sanitize` now ends with `pg_mod_rna_sanitize`, which applies Blender's limits to
    81 mapped parameters. The 81 hand clamps for exactly those parameters were removed. Flags and
    2D-adapted parameters keep PG's handling.
  - ADAPTED: PG stores parameters as floats, so an int hard maximum of INT_MAX becomes 2147483520
    (the largest float below 2³¹). This avoids an undefined float→int cast.
- Test `tools/run_native_rna_ranges_tests.sh`: **555 sanitize results** equal what Blender's RNA
  setter stores.
- Safety: every mapped parameter at Blender's hard minimum and maximum went through PG's modifiers,
  with the PG code under ASan/UBSan: **131 evaluations, 0 reports**.

## Quirk register additions (mandatory parity, not "fixed")
- **Q-L4-1: Envelope `spread` hard max is INT_MAX.**
  - At that value Blender 3.6.23's own `MOD_gpencil_legacy_envelope.c` generate loop runs from
    `-spread` and creates O(spread) strokes, so it exhausts memory.
  - PG's loop is identical, so the extremes test lists this case as NOT RUN with the reason.
  - Keeping parity means a user can still trigger it. A PG safety cap would be a deliberate deviation;
    that is your decision.

## Not done / open (explicit)
- **Kotlin panel ranges (`ModifierSpecs`) are unchanged.** They still use PG's slider ranges.
  - Blender's soft ranges are meant for number fields. Used as PG's bar sliders, some would be
    unusable (Time start 0..1048574, Texture fill rotation ±10000).
  - That is a UI decision, which you asked me not to make. The native layer now enforces Blender's
    limits whatever the panel sends.
  - Panel values outside Blender's limits are clamped natively; the UI then shows the clamped value.
- **Time `frame_start/frame_end`**: the clamp is applied. Blender's "move the other end" side effect
  is not, because `modifier_set_params` replaces the whole array and does not say which field was
  edited (`shortcut:` comment in `project_grease_mod_rna.c`).
- Not yet wired to the table:
  - Shader FX parameters (`pg_fx_sanitize`). Blender 3.6.23 has no DNA defaults for FX; FX defaults
    come from each `FX_*.c` `initData` (L7).
  - Line Art settings: the setters exist; `PGLineartSettings` is not wired to them yet.
  - GP data properties (layer opacity and the like).
- Time mode 4 (CHAIN) is now accepted as a valid Blender item, but PG's Time rewrite implements only
  modes 0–3. That is an L7 gap.
- The Blender 3.6.23 `.blend` reader itself (`readfile.cc`) is not part of L2–L4; L2 provides its
  libraries and file layer.

## Verification
| Check | Result |
|---|---|
| L2 FileReader test, plain + ASan/UBSan (x86_64 host) | ALL PASSED, 0 sanitizer reports |
| L3 DNA defaults test, plain + ASan/UBSan | 129 compared, ALL PASSED, 0 reports |
| L4 table regenerated from Blender RNA = committed | up to date (709 properties) |
| L4 sanitize vs Blender RNA, plain + ASan/UBSan | 555 compared, ALL PASSED |
| L4 extremes through PG modifiers (PG code ASan/UBSan) | 131 evaluations, 0 reports (1 NOT RUN: Q-L4-1) |
| All existing native CI test scripts after the change | all pass except render (below) |
| Render test | **UNVERIFIED**: needs Mesa EGL/GLES (CI installs it) |
| `verify_blender_verbatim.py` | 101 regions, 0 failed |
| 29 new Android manifest sources, host clang with Android CMake flags/includes | 29/29 compile (proxy only) |
| Android NDK build arm64-v8a | **UNVERIFIED** (NDK download blocked in sandbox) |
| Android NDK build x86_64 | **UNVERIFIED** (same) |
| Kotlin unit tests / Gradle build | **UNVERIFIED** (no Android SDK; Maven blocked). No Kotlin file was changed |

L2–L4 are not claimed complete. That needs green CI on both ABIs.
