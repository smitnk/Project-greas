# FIX_REPORT — PR #50 (`feature/l1-implementation`) CI fixes

Nothing committed or pushed. The files in this ZIP replace the same paths in the working copy.
`verification/changes.diff` is the exact unified diff against the branch. The three originals
were re-created byte-exact: their git blob SHA-1s match GitHub.

## Problem 1 — duplicate symbols at the Android link

**Root cause.** `native/blender_gp/lineart/lineart_lite_runtime.cc` held Project Grease's
old stand-ins for Blender runtime code. L1 now links the real Blender 3.6.23 versions of all
but one of them. So **11** symbols were defined twice, not only the three in the CI log.
The reproduction link (`verification/VERIFICATION_LOG.md`) shows all 11.

| Symbol | Real definition (L1 closure) |
|---|---|
| `BLI_task_pool_create`, `_push`, `_work_and_wait`, `_free`, `_user_data` | `blenlib/intern/task_pool.cc` |
| `BLI_task_parallel_range` | `blenlib/intern/task_range.cc` (not task_pool.cc) |
| `BLI_spin_init`, `_lock`, `_unlock`, `_end` | `blenlib/intern/threads.cc` |
| `PIL_check_seconds_timer` | `blenlib/intern/time.c` |

**Fix.** All 11 stand-ins are removed. Only `Global G` remains: Line Art reads
`G.debug_value` and `G.is_break`, and Blender defines `G` in `blenkernel/intern/blender.c`,
which is not in the closure. Its symbol check was clean: `G` has no definition in the L1 objects.

**Why `task_pool.cc` (and `task_range.cc`, `threads.cc`, `time.c`) are kept.** They are
Blender 3.6.23's own implementations and part of the locked L1 closure. Built without TBB,
`task_pool.cc` runs each pushed task immediately and `task_range.cc` runs a serial loop, so
Line Art stays single-threaded and deterministic.

**Behavior checked against Blender's Line Art source:**
- At all three `BLI_task_pool_create` sites, every task's data is filled before the push.
  Running immediately (Blender) and running at `work_and_wait` (the old code) therefore give
  the same order and result.
- Line Art never sets `func_init`, so dropping the old stand-in's `func_init` call changes nothing.
- Spin locks are now real `pthread_spin_*` (bionic, minSdk 26) instead of no-ops. Every lock
  in the generated Line Art core has a matching `BLI_spin_init` / `BLI_spin_end`. A self-deadlock
  that the no-ops used to hide would now hang the Line Art test. That risk is **UNVERIFIED**
  until CI runs it.

**Follow-on fix in `tools/run_native_lineart_tests.sh`.**
- This host test compiles `lineart_lite_runtime.cc` against `native_host_closure.sh`, which has
  no task/threads/time sources. Without a change, the test would fail with undefined symbols.
- It now also compiles and links Blender's `time.c`, `gsqueue.c`, `task_pool.cc`,
  `task_range.cc`, `task_scheduler.cc` and `threads.cc`, only for this test.
- The shared closure is untouched, so no other test changes.

**Other users checked.**
- The Android JNI target and `android_blender_gp_native_link_probe.sh` both consume the
  manifest, so this one source change fixes both.
- `run_native_render_tests.sh` and `run_native_scene_lite_tests.sh` don't compile this file.
- `gen_lineart_lite.py --check` doesn't generate this file.
- `android_legacy_runtime_compat.c` defines none of these symbols.

**Exactly one definition each, after the fix.**
- Each of the 11 is now defined only by the Blender object in the table above.
- These symbols could not have a third definition elsewhere in the manifest: the base branch
  linked with `--no-undefined` and had no duplicates, while `lineart_lite_runtime.cc` defined
  all of them. L1 only added Blender files.
- **Not done:** a literal text search of the entire repository. That needs a checkout; only
  the files named above were read.

## Problem 2 — emulator workflow removed (`.github/workflows/android-shell.yml`)
- **Removed:**
  - the `workflow_dispatch` input `run_emulator`; `workflow_dispatch:` stays, with no inputs;
  - the whole `emulator-tests` job: KVM setup, `reactivecircus/android-emulator-runner`, sweep,
    monkey, screenshot/logcat upload;
  - `:app:assembleDebugAndroidTest` and the "Upload instrumented test APK" step. Only the
    emulator job consumed them, through the `project-grease-*-apk` download.
- **Kept:**
  - all native tests, including Line Art;
  - `testDebugUnitTest`;
  - `:app:assembleDebug`;
  - native link-closure verification;
  - APK verification and content checks;
  - the APK upload;
  - `tools/test_logcat_triage.py`, which is an offline Python unit test that needs no emulator.
- The YAML parses, with one job: `android-shell`.

## Tests actually executed (this environment: x86_64 Linux, gcc 13; no network, NDK or repo checkout)
1. **Reproduced the CI failure:** original `lineart_lite_runtime.cc` + Blender 3.6.23 L1
   objects gives 11 `multiple definition` errors.
2. **Fixed file links cleanly** with `--no-undefined`. A probe calling every removed symbol
   through Blender's implementations runs correctly: pool tasks run, user data is returned,
   the parallel range fills its output, the timer works.
3. **Symbol tables** (`nm`): the fixed object defines only `G`.
4. **Workflow:** YAML valid; zero occurrences of `run_emulator`, `emulator-tests`, the
   emulator runner, `assembleDebugAndroidTest`, `androidTest`, screenshots or monkey.
5. **`bash -n`** on the modified test script: OK.

## Not executable here
- The Android GP application build (`assembleDebug`) and `android_blender_gp_native_link_probe.sh`
  with NDK 27 / `ld.lld` (no NDK).
- `tools/run_native_lineart_tests.sh`: needs the repository checkout, generated DNA and the
  Blender 3.6.23 Line Art reference from CI. This includes the spin-lock deadlock check.
- All other native and Android unit tests in the workflow.

The Android build is **not** claimed to pass. L1 is **not** complete: the per-ABI parity gates
(arm64-v8a and x86_64) still have to pass in CI and on a device.
