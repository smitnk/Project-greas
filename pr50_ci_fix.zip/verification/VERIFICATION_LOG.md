# Verification log (host x86_64, gcc 13.3, Blender 3.6.23 tarball == e467db79)

## Originals re-created byte-exact (git blob SHA-1 matches GitHub on feature/l1-implementation)
4c17a216cecbfef7061459f56f30fbc0eb10f4e8 orig/lineart_lite_runtime.cc
4e3458a3fc0c9f2cf37a130edd6a689718d4c6fb orig/tools/run_native_lineart_tests.sh
2090feaf58614d103a2583e6657ba9f05aa1b091 orig/.github/workflows/android-shell.yml

## Symbols defined by lineart_lite_runtime.cc
### orig
T BLI_spin_end
T BLI_spin_init
T BLI_spin_lock
T BLI_spin_unlock
T BLI_task_parallel_range
T BLI_task_pool_create
T BLI_task_pool_free
T BLI_task_pool_push
T BLI_task_pool_user_data
T BLI_task_pool_work_and_wait
B G
T PIL_check_seconds_timer
### new
B G

## Which Blender 3.6.23 L1 object defines each removed symbol
BLI_task_pool_create: task_pool.cc.o 
BLI_task_pool_push: task_pool.cc.o 
BLI_task_pool_work_and_wait: task_pool.cc.o 
BLI_task_pool_free: task_pool.cc.o 
BLI_task_pool_user_data: task_pool.cc.o 
BLI_task_parallel_range: task_range.cc.o 
PIL_check_seconds_timer: time.c.o 
BLI_spin_init: threads.cc.o 
BLI_spin_lock: threads.cc.o 
BLI_spin_unlock: threads.cc.o 
BLI_spin_end: threads.cc.o 
G: 
(G: no definition in the L1 objects; Blender defines it in blenkernel/intern/blender.c, which is not in the closure -> kept in lineart_lite_runtime.cc)

## Link test: probe + lineart_lite_runtime.o + Blender L1 objects (-Wl,--no-undefined)
### orig
multiple definition of `BLI_spin_end
multiple definition of `BLI_spin_init
multiple definition of `BLI_spin_lock
multiple definition of `BLI_spin_unlock
multiple definition of `BLI_task_parallel_range
multiple definition of `BLI_task_pool_create
multiple definition of `BLI_task_pool_free
multiple definition of `BLI_task_pool_push
multiple definition of `BLI_task_pool_user_data
multiple definition of `BLI_task_pool_work_and_wait
multiple definition of `PIL_check_seconds_timer
LINK FAILED
### new
LINK OK
pool=1111 userdata=1 range_last=49 timer_positive=1 G.debug_value=0

## Workflow checks
YAML valid; jobs = ['android-shell'] ; workflow_dispatch inputs = None
run_emulator occurrences: 0
emulator-tests occurrences: 0
android-emulator-runner occurrences: 0
assembleDebugAndroidTest occurrences: 0
androidTest occurrences: 0
screenshots occurrences: 0
monkey occurrences: 0
kept steps:
172:        run: bash tools/run_native_lineart_tests.sh
199:        run: python3 tools/test_logcat_triage.py
201:      - name: Run Android unit tests
205:      - name: Build Android GP application
209:      - name: Verify Android GP native link closure
219:      - name: Verify APK
304:      - name: Upload APK artifact

## bash -n
run_native_lineart_tests.sh syntax OK
