/* Link probe: references every symbol formerly in lineart_lite_runtime.cc. */
#include <stdio.h>
#include "BLI_task.h"
#include "BLI_threads.h"
#include "PIL_time.h"
#include "BKE_global.h"
static void run(TaskPool *__restrict p, void *d) { (void)p; (*(int *)d)++; }
static void rng(void *__restrict u, int i, const TaskParallelTLS *__restrict t) { (void)t; ((int *)u)[i] = i * i; }
int main(void)
{
  int v[4] = {0}, r[8];
  SpinLock s; BLI_spin_init(&s); BLI_spin_lock(&s); BLI_spin_unlock(&s); BLI_spin_end(&s);
  TaskPool *tp = BLI_task_pool_create(v, TASK_PRIORITY_HIGH);
  for (int i = 0; i < 4; i++) BLI_task_pool_push(tp, run, &v[i], false, NULL);
  BLI_task_pool_work_and_wait(tp);
  int ud_ok = BLI_task_pool_user_data(tp) == (void *)v;
  BLI_task_pool_free(tp);
  TaskParallelSettings st; BLI_parallel_range_settings_defaults(&st);
  BLI_task_parallel_range(0, 8, r, rng, &st);
  double t = PIL_check_seconds_timer();
  printf("pool=%d%d%d%d userdata=%d range_last=%d timer_positive=%d G.debug_value=%d\n", v[0], v[1], v[2], v[3], ud_ok, r[7], t > 0, G.debug_value);
  return 0;
}
