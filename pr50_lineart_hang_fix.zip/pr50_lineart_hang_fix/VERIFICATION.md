# Verification

| Check | Result |
|---|---|
| Reproduced CI hang with unmodified `tools/run_native_lineart_tests.sh` @972fabbc (x86_64 host) | Hang reproduced: no output after "generated Line Art source is up to date" |
| Backtrace of the stuck process (972fabbc and 4b0ebfb) | Done, `logs/gdb_backtraces.txt` |
| `bash tools/run_native_lineart_tests.sh` with fix: plain build | **ALL PASSED**, exit 0 |
| Same script: ASan + UBSan build (`-g -fsanitize=address,undefined`) | **ALL PASSED**, 0 sanitizer reports |
| Total script time (both builds, both runs) | 17.2 s (pre-L1 custom runtime: ~12 s) |
| `tools/gen_lineart_lite.py --check` | up to date |
| Regression watchdog catches the bug (fix line removed) | exit 2, `FAIL: watchdog: Line Art test hung: test_shadow_and_light_contour` |
| Existing Line Art assertions weakened | None; only the calls were wrapped in `RUN()` |
| Comparison against Blender 3.6.23 reference output (`LINEART_REFERENCE_DIR`) | **UNVERIFIED** locally: download.blender.org is blocked in this sandbox. CI runs it. |
| arm64-v8a | **UNVERIFIED** (host test is x86_64; Android ABI builds/tests not run here) |
| x86_64 Android | **UNVERIFIED** (only the x86_64 Linux host test ran) |

Not claimed: L1 complete. That still needs green CI on both ABIs plus the reference compare.
