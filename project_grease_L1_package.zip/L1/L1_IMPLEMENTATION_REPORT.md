# L1 Implementation Report — Project Grease (Blender 3.6.23 BLI closure)

Branch inspected (read-only): `feature/project-grease-ui-real-integration`
Blender source: the supplied `blender-3.6.23.tar.xz`. Confirmed identical to the pinned
commit `e467db79ca8cc5c1c15e1a0e08bd52ca419f2eca`: git blob SHA-1s of `math_matrix.c`,
`math_vector.c`, `string.c` and `BLI_simd.h` match the commit, and `BKE_blender_version.h`
gives 306 / patch 23 / release.
SSE2NEON: v1.6.0 `sse2neon.h`, blob SHA-1 `0db48053…` (matches GitHub at tag v1.6.0).
Blender pins this version in `build_files/build_environment/cmake/versions.cmake:581`.

## OVERALL STATUS: L1 NOT COMPLETE

| Check | Result |
|---|---|
| Host x86_64 build of the L1 closure (gcc 13, `--no-undefined`) | PASS |
| Host Blender-config reference generated, deterministic across runs | PASS |
| Host evidence that the old Project Grease config diverges from Blender | PASS (3 divergences reproduced) |
| **Android arm64-v8a build** | **UNVERIFIED** (no NDK in this environment) |
| **Android arm64-v8a parity run** | **UNVERIFIED** (no arm64 device or emulator) |
| **Android x86_64 build** | **UNVERIFIED** (no NDK) |
| **Android x86_64 parity run** | **UNVERIFIED** (no emulator) |
| Full Project Grease JNI build with the changes applied | **UNVERIFIED** |
| CI workflow | **UNVERIFIED** (written, never executed) |

L1 can only be called complete after the CI/device runs in section 9 pass on both ABIs.

## 1. Project Grease files read
- `tools/import_blender_gp.sh`: clones blender.git at e467db79 into `third_party/blender`.
- `tools/android_gp_source_manifest.txt`: the authoritative Android object list (`C|`/`CXX|`).
- `android/app/src/main/cpp/CMakeLists.txt`: compiles the manifest; sets MATH_STANDALONE on
  math_matrix/vector/rotation; links with `--no-undefined --gc-sections`; has no Blender
  platform flags.
- `tools/android_blender_gp_generate_dna.sh`: host makesdna. Unaffected by L1.

## 2. Source reviews (verified against the tarball)

**`string.c`, `string_utf8.c`**
- Each has exactly one `#ifdef __GNUC__`, which only guards `#pragma GCC diagnostic error
  "-Wsign-conversion"`.
- KEEP Project Grease's wrappers: they pre-include the headers and hide `__GNUC__` only to
  skip that pragma.
- But see 3b: these wrappers are also why the x86_64 build currently compiles with signed
  `char` without errors.

**`math_vector.c`, `math_rotation.c`**
- No reference to `MATH_STANDALONE`, so the define has no effect on them. Compiled directly now.

**`math_matrix.c`**
- `MATH_STANDALONE` replaces `EIG_invert_m4_m4` with `invert_m4_m4_fallback`, and compiles out
  `mat3_polar_decompose` / `interp_m3_m3m3` / `interp_m4_m4m4`.
- REMOVED the define; added the Eigen C API.

**`math_base.c`, `math_color.c`**
- Added to the closure. Not needed by the harness link (proven by link-removal test), but
  required by later L5 callers (`rgb_to_hsv_v` etc.); `--gc-sections` drops unused code.
- `math_*_inline.c` are NOT added: they reach callers through the headers (link test proved
  them removable).

**`math_solvers.c`**
- Requires `EIG_self_adjoint_eigen_solve` and `EIG_svd_square_matrix` even with
  MATH_STANDALONE (proven by an undefined-symbol link failure). So `intern/eigen` `svd.cc` and
  `eigenvalues.cc` are required, not optional.

**Task system (non-TBB)**
- `task_range.cc`: without `WITH_TBB`, `BLI_task_parallel_range` runs a serial loop.
- `task_pool.cc`: without TBB, pushed tasks run immediately (serial).
- `task_scheduler.cc`: required for `BLI_task_scheduler_num_threads` (link-proven).
- Result: deterministic, no TBB.

**SIMD users in the closure**
- `math_matrix.c` (`mul_m4_m4m4`), `math_color_inline.c`, `math_base_inline.c` (via `BLI_HAVE_SSE2`).
- Eigen (via `__SSE2__`, independently of `BLI_simd.h`).

## 3. Parity findings proven by host builds (`tests/l1_parity/diff_*.txt`)

Reference = Blender 3.6.23's own Linux configuration (`platform_unix.cmake`, Clang/GCC branch:
`-funsigned-char -fno-strict-aliasing -ffp-contract=off`, SIMD on, Eigen, no MATH_STANDALONE).

**a. MATH_STANDALONE changes results** (`pg_before_math`)
- `invert_m4_m4` output differs in the last bits on a regular matrix.
- Signs of zeros differ on a near-singular matrix.
- `m * inv` is no longer the same matrix.

**b. Signed `char` breaks UTF-8 handling** (`pg_signed_char`)
- Reproduced with Project Grease's own `__GNUC__`-hiding wrapper technique and `-fsigned-char`
  (the Android x86_64 default). Without the wrapper, Blender's `string_utf8.c`,
  `math_vector.c` and `BLI_kdopbvh.c` do not even compile with signed char under GCC.
- `BLI_str_utf8_size_safe("é")` returns 1 instead of 2.
- `BLI_strncpy_utf8` truncation leaves a partial UTF-8 sequence (`61 62 c3` vs Blender's `61 62`).
- This affects `BLI_uniquename` truncation, which feeds modifier seeds.
- Fix: `-funsigned-char` (Blender's own flag). Android arm64 is unsigned by default;
  x86_64 is not.

**c. SIMD path differences** (`pg_l1_scalar`, attributed by rebuilding single objects)
- `mul_m4_m4m4`, BLI's SSE path vs scalar: last-bit differences. Fixed on arm64 by
  WITH_SSE2NEON + sse2neon v1.6.0, exactly as Blender does.
- `EIG_invert_m4_m4`, Eigen 3.3.7 `Inverse_SSE.h` vs generic: differences.
  - Eigen checks `__SSE2__`, not `BLI_HAVE_SSE2`, so **sse2neon does not change Eigen**.
  - Official Blender on arm64 also uses Eigen's generic 4×4 inverse.
  - **Consequence: Blender 3.6.23 itself is not bit-identical between x86_64 and arm64.**

**Parity decision**
- Parity is defined per ABI: Android x86_64 vs Blender's x86_64 configuration, and Android
  arm64-v8a vs Blender's Linux arm64 configuration (`blender_ref_arm64`: same flags +
  WITH_SSE2NEON).
- Cross-ABI bit-identity is not a valid target, because official Blender does not have it.

**Known platform risk (UNVERIFIED)**
- Android uses bionic libm; the Linux reference uses glibc libm.
- Outputs depending on `sinf`/`cosf`/`atan2f`/`acosf` (eul/quat/angle lines) may differ in
  the last bit between platforms even with identical source and flags.
- If CI shows differences only on those lines, that is a libm difference, not an L1 port
  error. It would need a separate decision (e.g. accept, or vendor a libm).

## 4. Exact Blender 3.6.23 sources in the L1 closure
- Already in the manifest (KEEP): `listbase.cc`, `rand.cc`, `BLI_assert.c`, `noise.c`,
  `math_geom.c`, `polyfill_2d.c`, `BLI_memarena.c`, `BLI_heap.c`, `stack.c`, `BLI_ghash.c`,
  `BLI_ghash_utils.c`, `BLI_mempool.c`, `hash_mm2a.c`, `string_utils.c`, `string.c` /
  `string_utf8.c` (via wrappers), guardedalloc (`mallocn*.c`, `leak_detector.cc`,
  `memory_usage.cc`). Header-only: `BLI_hash.h`, `BLI_utildefines.h`, `BLI_compiler_attrs.h`,
  `BLI_sys_types.h`, `intern/atomic`.
- Wrapper → direct upstream (ADAPT): `math_vector.c`, `math_matrix.c`, `math_rotation.c`.
- Added (PORT): `math_base.c`, `math_color.c`, `math_solvers.c`, `BLI_heap_simple.c`,
  `BLI_kdopbvh.c`, `DLRB_tree.c`, `BLI_dynstr.c`, `gsqueue.c`, `time.c`, `task_pool.cc`,
  `task_range.cc`, `task_scheduler.cc`, `threads.cc`, `extern/wcwidth/wcwidth.c`,
  `intern/eigen/intern/{matrix,svd,eigenvalues}.cc`. Headers come from `intern/eigen` and
  `extern/Eigen3` (3.3.7).
- Copies with blob SHA-1s are in `blender_sources/`. Build from `third_party/blender`, not
  from these copies.

## 5. Dependency graph (link-proven on host)
```
BLI_kdopbvh.c ─▶ BLI_heap_simple.c, stack.c, task_range.cc, math_* (vector/geom)
task_range.cc ─▶ task_scheduler.cc, threads.cc
task_pool.cc  ─▶ BLI_mempool.c, threads.cc, task_scheduler.cc
threads.cc    ─▶ gsqueue.c, listbase.cc, time.c (PIL_check_seconds_timer), pthreads
math_matrix.c ─▶ intern/eigen matrix.cc (EIG_invert_m4_m4) ─▶ extern/Eigen3
math_solvers.c ─▶ intern/eigen svd.cc, eigenvalues.cc
rand.cc       ─▶ noise.c (BLI_noise_hash_uchar_512)
string.c      ─▶ BLI_dynstr.c
string_utf8.c ─▶ extern/wcwidth/wcwidth.c
string_utils.c ─▶ string.c, string_utf8.c, listbase.cc
BLI_ghash.c   ─▶ BLI_mempool.c, hash_mm2a.c, BLI_ghash_utils.c
polyfill_2d.c ─▶ BLI_memarena.c
everything    ─▶ guardedalloc, BLI_assert.c, intern/atomic
```

## 6. Files in this package
- `tools/apply_l1_changes.py` — **the change set**.
  - Edits the real `tools/android_gp_source_manifest.txt` and
    `android/app/src/main/cpp/CMakeLists.txt` by exact anchors; aborts if an anchor is not
    found exactly once.
  - Tested against a transcription of the branch's files: manifest result has 119 lines and
    no duplicates.
  - Usage: `python3 tools/apply_l1_changes.py --package <unzipped package>`
- `updated_files/android_gp_source_manifest.L1.txt` — the manifest after the script,
  generated from my transcription (reference only; the script is authoritative).
- `third_party/sse2neon/` — `sse2neon.h` v1.6.0, `LICENSE` (MIT), `VERSION.txt`.
- `tests/l1_parity/l1_parity_harness.c` — prints every result as an exact bit pattern
  (hash, halton, matrix inverse incl. singular/near-singular, matrix multiply, vector,
  rotation, color, Newton solver converging/non-converging, polyfill, heap tie order, GHash
  int/str iteration order, DLRB tree, uniquename, UTF-8, BVH nearest/ray, task range/pool).
- `tests/l1_parity/build_l1_host.sh`, `run_host_parity.sh` — host configs:
  `blender_ref`, `blender_ref_arm64`, `pg_before_math`, `pg_signed_char`, `pg_l1_scalar`.
- `tests/l1_parity/pg_wrappers/` — test-only reproduction of the current string wrapper with signed char.
- `tests/l1_parity/android/CMakeLists.txt` — NDK executable build of the harness, with the same flags as the JNI target.
- `tests/l1_parity/reference_blender_3.6.23_linux_x86_64_gcc13.txt` and `diff_ref_vs_*.txt` — host results.
- `.github/workflows/l1-bli-parity.yml` — per-ABI reference jobs, NDK builds for both ABIs, x86_64 emulator run + diff.
- `blender_sources/` — copies of the added Blender files + `GIT_BLOB_SHA1.txt`.

### Changes the script makes
**Manifest:**
- 3 math wrapper lines → `math_vector.c`, `math_matrix.c`, `math_rotation.c`, `math_base.c`,
  `math_color.c`, `math_solvers.c`.
- After `BLI_heap.c`: `BLI_heap_simple.c`, `BLI_kdopbvh.c`, `DLRB_tree.c`, `BLI_dynstr.c`,
  `gsqueue.c`, `time.c`, `wcwidth.c`, the 4 task/thread `.cc` files and the 3 Eigen `.cc` files.

**CMake:**
- Remove the MATH_STANDALONE block.
- Add `intern/eigen` and `extern/Eigen3` includes.
- Add `-funsigned-char -fno-strict-aliasing -ffp-contract=off`.
- arm64-v8a only: `WITH_SSE2NEON` + `third_party/sse2neon`.
- No `-ffast-math` anywhere.

**Now unused, not deleted:** `native/blender_gp/android_blender_math_{vector,matrix,rotation}_compat.c`.

## 7. Android-specific adaptations
- No TBB: Blender's own non-TBB paths are used (serial range, immediate pool execution).
- pthreads from bionic for `threads.cc`.
- arm64: sse2neon v1.6.0 with Blender's own `BLI_simd.h` settings (PRECISE_MINMAX/DIV/SQRT=1).
- No Project Grease architecture, UI, GHOST/WM/DRW/Scene changes; no OpenToonz, no GL4ES.

## 8. Risks introduced (UNVERIFIED)
- `-funsigned-char` applies to the whole JNI target, including Project Grease's own C code.
  It matches Blender, but any Project Grease code that relies on signed `char` would change
  on x86_64. arm64 already behaves this way. Review `char` comparisons in `native/blender_gp`.
- Eigen in Blender may be built with OpenMP. That only parallelizes large dynamic matrices,
  so it does not affect the 4×4/3×3 paths used here.
- sse2neon v1.6.0 has not been compiled with NDK clang here.

## 9. Required before L1 can be called complete
1. Run `apply_l1_changes.py` on the branch; build the APK for arm64-v8a and x86_64.
2. CI: the `reference` (x86_64 + arm64 Linux) and `android` jobs build; `run-x86_64` diff is empty.
3. arm64-v8a: run the NDK harness on an arm64 device/emulator; `diff ref_arm64.txt android_arm64.txt` is empty.
4. If only libm-dependent lines differ, record and decide (section 3).
