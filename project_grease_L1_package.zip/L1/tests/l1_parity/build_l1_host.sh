#!/usr/bin/env bash
# Build the L1 parity harness on a host from the pinned Blender 3.6.23 tree.
# Usage: BLENDER=<tree> CONFIG=<blender_ref|pg_before_math|pg_signed_char|pg_l1_scalar> OUT=<dir> ./build_l1_host.sh
set -euo pipefail
: "${BLENDER:?}" ; : "${CONFIG:?}" ; : "${OUT:?}"
CC="${CC:-gcc}"; CXX="${CXX:-g++}"; SSE2NEON_DIR="${SSE2NEON_DIR:-}"
HERE="$(cd "$(dirname "$0")" && pwd)"
B="$BLENDER/source/blender"
mkdir -p "$OUT/obj"

INC=(-I"$B/blenlib" -I"$B/makesdna" -I"$BLENDER/source" -I"$BLENDER/intern/guardedalloc"
     -I"$BLENDER/intern/atomic" -I"$BLENDER/intern/eigen" -I"$BLENDER/extern/Eigen3"
     -I"$BLENDER/extern/wcwidth")
COMMON=(-O2 -DNDEBUG -fPIC)
case "$CONFIG" in
  blender_ref)   # Blender 3.6.23 platform_unix.cmake flags, Eigen on, SIMD as compiler default.
    FLAGS=(-funsigned-char -fno-strict-aliasing -ffp-contract=off); MATH_DEFS=() ;;
  pg_before_math) # Project Grease BEFORE L1, math only: MATH_STANDALONE (no Eigen), Blender flags kept
    FLAGS=(-funsigned-char -fno-strict-aliasing -ffp-contract=off); MATH_DEFS=(-DMATH_STANDALONE) ;;
  pg_signed_char)  # L1 flags, but the string sources built with signed char (Android x86_64 default)
    FLAGS=(-funsigned-char -fno-strict-aliasing -ffp-contract=off); MATH_DEFS=() ;;
  blender_ref_arm64)  # Blender 3.6.23 Linux arm64 config: same flags + WITH_SSE2NEON (run on an arm64 host)
    FLAGS=(-funsigned-char -fno-strict-aliasing -ffp-contract=off -DWITH_SSE2NEON -I"$SSE2NEON_DIR"); MATH_DEFS=() ;;
  pg_l1_scalar)  # L1 flags but BLI_HAVE_SSE2 off: models arm64 WITHOUT sse2neon.
    FLAGS=(-funsigned-char -fno-strict-aliasing -ffp-contract=off -U__SSE2__); MATH_DEFS=() ;;
  *) echo "unknown CONFIG" >&2; exit 2 ;;
esac

C_SRC=(
  blenlib/intern/BLI_assert.c blenlib/intern/BLI_dynstr.c blenlib/intern/BLI_ghash.c
  blenlib/intern/BLI_ghash_utils.c blenlib/intern/BLI_heap.c blenlib/intern/BLI_heap_simple.c
  blenlib/intern/BLI_kdopbvh.c blenlib/intern/BLI_memarena.c blenlib/intern/BLI_mempool.c
  blenlib/intern/DLRB_tree.c blenlib/intern/gsqueue.c blenlib/intern/hash_mm2a.c
  blenlib/intern/math_base.c blenlib/intern/math_base_inline.c blenlib/intern/math_color.c
  blenlib/intern/math_color_inline.c blenlib/intern/math_geom.c blenlib/intern/math_geom_inline.c
  blenlib/intern/math_matrix.c blenlib/intern/math_rotation.c blenlib/intern/math_solvers.c
  blenlib/intern/math_vector.c blenlib/intern/math_vector_inline.c blenlib/intern/noise.c blenlib/intern/polyfill_2d.c
  blenlib/intern/stack.c blenlib/intern/string.c blenlib/intern/string_utf8.c
  blenlib/intern/string_utils.c blenlib/intern/time.c blenlib/intern/system.c
)
CXX_SRC=(
  blenlib/intern/listbase.cc blenlib/intern/rand.cc blenlib/intern/task_pool.cc
  blenlib/intern/task_range.cc blenlib/intern/task_scheduler.cc blenlib/intern/threads.cc
)
EXT_C=("$BLENDER/intern/guardedalloc/intern/mallocn.c"
       "$BLENDER/intern/guardedalloc/intern/mallocn_guarded_impl.c"
       "$BLENDER/intern/guardedalloc/intern/mallocn_lockfree_impl.c"
       "$BLENDER/extern/wcwidth/wcwidth.c")
EXT_CXX=("$BLENDER/intern/guardedalloc/intern/leak_detector.cc"
         "$BLENDER/intern/guardedalloc/intern/memory_usage.cc"
         "$BLENDER/intern/eigen/intern/matrix.cc"
         "$BLENDER/intern/eigen/intern/svd.cc"
         "$BLENDER/intern/eigen/intern/eigenvalues.cc")

OBJS=()
compile() { # lang src
  local o="$OUT/obj/$(echo "$2" | tr '/' '_').o"
  if [[ $1 == c ]]; then "$CC" -std=gnu11 "${COMMON[@]}" "${FLAGS[@]}" "${MATH_DEFS[@]}" "${INC[@]}" -c "$2" -o "$o"
  else "$CXX" -std=c++17 "${COMMON[@]}" "${FLAGS[@]}" "${MATH_DEFS[@]}" "${INC[@]}" -c "$2" -o "$o"; fi
  OBJS+=("$o")
}
for s in "${C_SRC[@]}"; do
  if [[ "$CONFIG" == pg_signed_char && "$s" == blenlib/intern/string_utf8.c ]]; then
    # Reproduce the current Android x86_64 build: Project Grease's __GNUC__-hiding
    # wrapper, compiled with signed char (Android x86_64 default).
    ln -sf "$B/$s" "$OUT/string_utf8_upstream.c"
    o="$OUT/obj/pg_string_utf8_wrapper.o"
    "$CC" -std=gnu11 "${COMMON[@]}" -fno-strict-aliasing -ffp-contract=off -fsigned-char -w \
      "${INC[@]}" -I"$OUT" -c "$HERE/pg_wrappers/pg_string_utf8_wrapper.c" -o "$o"
    OBJS+=("$o"); continue
  fi
  [[ -f "$B/$s" ]] && compile c "$B/$s"
done
for s in "${CXX_SRC[@]}"; do compile cxx "$B/$s"; done
for s in "${EXT_C[@]}"; do compile c "$s"; done
for s in "${EXT_CXX[@]}"; do compile cxx "$s"; done
compile c "$HERE/l1_parity_harness.c"
"$CXX" "${OBJS[@]}" -Wl,--no-undefined -lpthread -lm -o "$OUT/l1_parity_harness"
echo "built $OUT/l1_parity_harness ($CONFIG)"
