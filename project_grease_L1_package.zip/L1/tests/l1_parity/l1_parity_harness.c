/* Project Grease L1 parity harness.
 * Exercises the Blender 3.6.23 BLI L1 closure and prints every result as an
 * exact bit pattern, so two builds can be compared byte-for-byte.
 * Only Blender's public BLI API is called; no algorithm is reimplemented here. */
#include <math.h>
#include <stdio.h>
#include <string.h>

#include "MEM_guardedalloc.h"

#include "BLI_dlrbTree.h"
#include "BLI_ghash.h"
#include "BLI_hash.h"
#include "BLI_heap.h"
#include "BLI_kdopbvh.h"
#include "BLI_listbase.h"
#include "BLI_math.h"
#include "BLI_math_solvers.h"
#include "BLI_polyfill_2d.h"
#include "BLI_rand.h"
#include "BLI_string_utf8.h"
#include "BLI_string_utils.h"
#include "BLI_task.h"
#include "BLI_utildefines.h"

static unsigned int fbits(float f) { unsigned int u; memcpy(&u, &f, 4); return u; }
static unsigned long long dbits(double d) { unsigned long long u; memcpy(&u, &d, 8); return u; }
static void pf(const char *tag, const float *v, int n)
{
  printf("%s", tag);
  for (int i = 0; i < n; i++) printf(" %08x", fbits(v[i]));
  printf("\n");
}

/* ---------------- hash / halton ---------------- */
static void test_hash(void)
{
  const char *names[] = {"GP_Noise", "Noise", "Noise.001", "Array", "Offset", "Length", "Stroke"};
  for (int i = 0; i < 7; i++) printf("hash_string %s %08x\n", names[i], BLI_hash_string(names[i]));
  for (unsigned int k = 0; k < 64; k += 7) {
    printf("hash_int %u %08x %08x %08x\n", k, BLI_hash_int(k), BLI_hash_int_2d(k, k * 3u + 1u),
           fbits(BLI_hash_int_01(k)));
  }
  const unsigned int p2[2] = {2, 3}, p3[3] = {2, 3, 7};
  double o2[2] = {0.0, 0.0}, o3[3] = {0.1, 0.2, 0.3}, r[3];
  for (int n = 1; n < 12; n += 3) {
    BLI_halton_2d(p2, o2, n, r);
    printf("halton2 %d %016llx %016llx\n", n, dbits(r[0]), dbits(r[1]));
    BLI_halton_3d(p3, o3, n, r);
    printf("halton3 %d %016llx %016llx %016llx\n", n, dbits(r[0]), dbits(r[1]), dbits(r[2]));
  }
}

/* ---------------- math ---------------- */
static void test_math(void)
{
  float loc[3] = {1.25f, -3.5f, 0.75f}, eul[3] = {0.3f, -1.1f, 2.7f}, size[3] = {1.5f, 0.2f, -2.0f};
  float m[4][4], inv[4][4], prod[4][4], q[4], eu[3], v[3];
  loc_eul_size_to_mat4(m, loc, eul, size);
  pf("loc_eul_size_to_mat4", &m[0][0], 16);
  printf("invert_m4_m4 %d\n", invert_m4_m4(inv, m));
  pf("inv", &inv[0][0], 16);
  mul_m4_m4m4(prod, m, inv);
  pf("mul_m4_m4m4(m,inv)", &prod[0][0], 16);
  float a[4][4] = {{0.1f, 0.7f, -0.3f, 0}, {2.2f, -1.9f, 0.4f, 0}, {0.05f, 0.33f, 1.7f, 0}, {9.1f, -4.4f, 3.3f, 1}};
  mul_m4_m4m4(prod, a, m);
  pf("mul_m4_m4m4(a,m)", &prod[0][0], 16);
  /* singular + near singular */
  float s[4][4] = {{1, 2, 3, 0}, {2, 4, 6, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}};
  printf("invert_singular %d\n", invert_m4_m4(inv, s));
  invert_m4_m4_safe(inv, s);
  pf("invert_m4_m4_safe(singular)", &inv[0][0], 16);
  float ns[4][4] = {{1e-8f, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}};
  printf("invert_nearsingular %d\n", invert_m4_m4(inv, ns));
  pf("inv_nearsingular", &inv[0][0], 16);
  printf("mat4_to_scale %08x\n", fbits(mat4_to_scale(m)));
  printf("is_negative_m4 %d\n", is_negative_m4(m));
  /* vector */
  float x[3] = {0.3f, -0.9f, 0.4f}, y[3] = {-1.2f, 0.25f, 2.0f}, ax[3] = {0, 0, 1};
  printf("angle_v3v3 %08x\n", fbits(angle_v3v3(x, y)));
  printf("angle_on_axis %08x\n", fbits(angle_on_axis_v3v3_v3(x, y, ax)));
  normalize_v3_v3(v, x);
  rotate_normalized_v3_v3v3fl(eu, y, v, 0.77f);
  pf("rotate_normalized_v3_v3v3fl", eu, 3);
  interp_v3_v3v3(v, x, y, 0.3333f);
  pf("interp_v3_v3v3", v, 3);
  float cl[3], l1[3] = {0, 0, 0}, l2[3] = {3, 1, -2};
  closest_to_line_segment_v3(cl, y, l1, l2);
  pf("closest_to_line_segment_v3", cl, 3);
  /* rotation */
  eul_to_quat(q, eul);
  pf("eul_to_quat", q, 4);
  float m3[3][3];
  quat_to_mat3(m3, q);
  pf("quat_to_mat3", &m3[0][0], 9);
  mat3_to_eul(eu, m3);
  pf("mat3_to_eul", eu, 3);
  axis_angle_to_quat(q, y, 1.234f);
  pf("axis_angle_to_quat", q, 4);
  /* color */
  float rgb[3] = {0.8f, 0.3f, 0.15f}, hsv[3], back[3];
  rgb_to_hsv_v(rgb, hsv);
  hsv_to_rgb_v(hsv, back);
  pf("rgb_to_hsv_v", hsv, 3);
  pf("hsv_to_rgb_v", back, 3);
  printf("interpf %08x fractf %08x\n", fbits(interpf(0.2f, 7.5f, 0.37f)), fbits(fractf(-3.75f)));
}

/* ---------------- solver ---------------- */
static void nd_delta(void *ud, const float x[3], float r[3])
{
  const float *t = ud;
  r[0] = x[0] * x[0] + x[1] - t[0];
  r[1] = x[1] * x[2] - t[1];
  r[2] = x[0] + x[1] + x[2] - t[2];
}
static void nd_jac(void *ud, const float x[3], float j[3][3])
{
  (void)ud;
  j[0][0] = 2 * x[0]; j[1][0] = 1;    j[2][0] = 0;
  j[0][1] = 0;        j[1][1] = x[2]; j[2][1] = x[1];
  j[0][2] = 1;        j[1][2] = 1;    j[2][2] = 1;
}
static void test_solver(void)
{
  float t[3] = {3.0f, 2.0f, 4.0f}, x0[3] = {1, 1, 1}, r[3];
  bool ok = BLI_newton3d_solve(nd_delta, nd_jac, NULL, t, 1e-6f, 20, false, x0, r);
  printf("newton3d ok=%d", ok); pf("", r, 3);
  float t2[3] = {-100.0f, 1e6f, 0.0f};
  ok = BLI_newton3d_solve(nd_delta, nd_jac, NULL, t2, 1e-9f, 3, false, x0, r);
  printf("newton3d_hard ok=%d", ok); pf("", r, 3);
}

/* ---------------- polyfill ---------------- */
static void test_polyfill(void)
{
  const float concave[7][2] = {{0, 0}, {4, 0}, {4, 3}, {2, 1}, {0, 3}, {-1, 1.5f}, {0.5f, 0.5f}};
  unsigned int tris[5][3];
  for (int sign = -1; sign <= 1; sign++) {
    BLI_polyfill_calc(concave, 7, sign, tris);
    printf("polyfill sign=%d", sign);
    for (int i = 0; i < 5; i++) printf(" %u,%u,%u", tris[i][0], tris[i][1], tris[i][2]);
    printf("\n");
  }
  const float degen[4][2] = {{0, 0}, {1, 0}, {2, 0}, {1, 0}};
  unsigned int t2[2][3];
  BLI_polyfill_calc(degen, 4, 0, t2);
  printf("polyfill_degenerate %u,%u,%u %u,%u,%u\n", t2[0][0], t2[0][1], t2[0][2], t2[1][0], t2[1][1], t2[1][2]);
}

/* ---------------- heap / ghash / dlrb ---------------- */
static void test_containers(void)
{
  Heap *h = BLI_heap_new();
  const float keys[10] = {3, 1, 2, 1, 5, -2, 2, 1, 0, 3};
  for (int i = 0; i < 10; i++) BLI_heap_insert(h, keys[i], POINTER_FROM_INT(i));
  printf("heap_order");
  while (!BLI_heap_is_empty(h)) printf(" %d", POINTER_AS_INT(BLI_heap_pop_min(h)));
  printf("\n");
  BLI_heap_free(h, NULL);

  GHash *gh = BLI_ghash_int_new(__func__);
  for (int i = 0; i < 40; i++) BLI_ghash_insert(gh, POINTER_FROM_INT(i * 37 % 101), POINTER_FROM_INT(i));
  for (int i = 0; i < 40; i += 3) BLI_ghash_remove(gh, POINTER_FROM_INT(i * 37 % 101), NULL, NULL);
  GHashIterator it;
  printf("ghash_int_order");
  GHASH_ITER (it, gh) printf(" %d", POINTER_AS_INT(BLI_ghashIterator_getKey(&it)));
  printf("\n");
  BLI_ghash_free(gh, NULL, NULL);

  GHash *gs = BLI_ghash_str_new(__func__);
  const char *strs[] = {"Layer", "Lines", "Fills", "Stroke", "GP_Layer.001", "Noise", "Tint"};
  for (int i = 0; i < 7; i++) BLI_ghash_insert(gs, (void *)strs[i], POINTER_FROM_INT(i));
  printf("ghash_str_order");
  GHASH_ITER (it, gs) printf(" %s", (const char *)BLI_ghashIterator_getKey(&it));
  printf("\n");
  BLI_ghash_free(gs, NULL, NULL);
}

typedef struct DNode { struct DNode *next, *prev, *left, *right, *parent; char tree_col; int key, hits; } DNode;
static short dcmp(void *node, void *data) { int a = *(int *)data, b = ((DNode *)node)->key; return (a < b) ? -1 : (a > b) ? 1 : 0; }
static DLRBT_Node *dnew(void *data) { DNode *n = MEM_callocN(sizeof(DNode), "dn"); n->key = *(int *)data; n->hits = 1; return (DLRBT_Node *)n; }
static void dupd(void *node, void *data) { (void)data; ((DNode *)node)->hits++; }
static void test_dlrb(void)
{
  DLRBT_Tree t;
  BLI_dlrbTree_init(&t);
  const int keys[12] = {5, 3, 9, 3, 1, 7, 9, 0, 4, 9, 2, 8};
  for (int i = 0; i < 12; i++) BLI_dlrbTree_add(&t, dcmp, dnew, dupd, (void *)&keys[i]);
  BLI_dlrbTree_linkedlist_sync(&t);
  printf("dlrb_order");
  for (DNode *n = t.first; n; n = n->next) printf(" %d:%d", n->key, n->hits);
  printf("\n");
  BLI_dlrbTree_free(&t, NULL);
}

/* ---------------- uniquename / utf8 ---------------- */
typedef struct NamedLink { struct NamedLink *next, *prev; char name[64]; } NamedLink;
static void test_uniquename(void)
{
  ListBase lb = {NULL, NULL};
  NamedLink items[5];
  memset(items, 0, sizeof(items));
  for (int i = 0; i < 5; i++) {
    strcpy(items[i].name, "Noise");
    BLI_addtail(&lb, &items[i]);
    BLI_uniquename(&lb, &items[i], "Noise", '.', offsetof(NamedLink, name), sizeof(items[i].name));
    printf("uniquename %d %s\n", i, items[i].name);
  }
  char buf[8];
  BLI_strncpy_utf8(buf, "ab\xc3\xa9\xe2\x82\xac" "cd", sizeof(buf));
  printf("strncpy_utf8 len=%zu", strlen(buf));
  for (size_t i = 0; i < strlen(buf); i++) printf(" %02x", (unsigned char)buf[i]);
  printf("\n");
  char small[4];
  BLI_strncpy_utf8(small, "ab\xc3\xa9", sizeof(small));
  printf("strncpy_utf8_truncate len=%zu", strlen(small));
  for (size_t i = 0; i < strlen(small); i++) printf(" %02x", (unsigned char)small[i]);
  printf("\n");
  printf("utf8_size %d %d\n", BLI_str_utf8_size_safe("\xc3\xa9"), BLI_str_utf8_size_safe("\xe2\x82\xac"));
}

/* ---------------- BVH ---------------- */
static void test_bvh(void)
{
  BVHTree *tree = BLI_bvhtree_new(64, 0.0f, 2, 6);
  for (int i = 0; i < 64; i++) {
    float co[3] = {BLI_hash_int_01(i * 3) * 10.0f, BLI_hash_int_01(i * 3 + 1) * 10.0f, BLI_hash_int_01(i * 3 + 2) * 10.0f};
    BLI_bvhtree_insert(tree, i, co, 1);
  }
  BLI_bvhtree_balance(tree);
  for (int k = 0; k < 4; k++) {
    float q[3] = {k * 2.5f, 10.0f - k * 2.0f, 3.0f + k};
    BVHTreeNearest nr = {-1, {0}, {0}, FLT_MAX, 0};
    int idx = BLI_bvhtree_find_nearest(tree, q, &nr, NULL, NULL);
    printf("bvh_nearest %d idx=%d", k, idx); pf("", &nr.dist_sq, 1);
    float dir[3] = {1, 0.1f * k, -0.2f};
    normalize_v3(dir);
    BVHTreeRayHit hit = {-1, {0}, {0}, BVH_RAYCAST_DIST_MAX};
    idx = BLI_bvhtree_ray_cast(tree, q, dir, 0.5f, &hit, NULL, NULL);
    printf("bvh_ray %d idx=%d", k, idx); pf("", &hit.dist, 1);
  }
  BLI_bvhtree_free(tree);
}

/* ---------------- task (deterministic, serial build) ---------------- */
static void range_cb(void *__restrict ud, int i, const TaskParallelTLS *__restrict tls)
{
  (void)tls;
  ((unsigned int *)ud)[i] = BLI_hash_int((unsigned int)i) ^ (unsigned int)(i * 2654435761u);
}
static void pool_cb(TaskPool *__restrict pool, void *taskdata)
{
  (void)pool;
  int *v = taskdata;
  *v = *v * 3 + 1;
}
static void test_task(void)
{
  unsigned int out[100];
  TaskParallelSettings st;
  BLI_parallel_range_settings_defaults(&st);
  BLI_task_parallel_range(0, 100, out, range_cb, &st);
  unsigned int acc = 0;
  for (int i = 0; i < 100; i++) acc = acc * 31u + out[i];
  printf("task_range %08x\n", acc);
  int vals[8] = {1, 2, 3, 4, 5, 6, 7, 8};
  TaskPool *p = BLI_task_pool_create(NULL, TASK_PRIORITY_HIGH);
  for (int i = 0; i < 8; i++) BLI_task_pool_push(p, pool_cb, &vals[i], false, NULL);
  BLI_task_pool_work_and_wait(p);
  BLI_task_pool_free(p);
  printf("task_pool");
  for (int i = 0; i < 8; i++) printf(" %d", vals[i]);
  printf("\n");
}

int main(void)
{
  test_hash();
  test_math();
  test_solver();
  test_polyfill();
  test_containers();
  test_dlrb();
  test_uniquename();
  test_bvh();
  test_task();
  return 0;
}
