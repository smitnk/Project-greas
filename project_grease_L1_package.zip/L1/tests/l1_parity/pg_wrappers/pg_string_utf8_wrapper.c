/* Test-only copy of Project Grease's android_blender_string_utf8_compat.c technique
 * (pre-include headers, hide __GNUC__ while including the unchanged upstream source).
 * Used ONLY by CONFIG=pg_signed_char to reproduce how the current Android x86_64
 * build compiles string_utf8.c with signed char. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <wctype.h>
#include "wcwidth.h"
#include "BLI_utildefines.h"
#include "BLI_string.h"
#include "BLI_string_utf8.h"
#pragma push_macro("__GNUC__")
#undef __GNUC__
#include "string_utf8_upstream.c"
#pragma pop_macro("__GNUC__")
