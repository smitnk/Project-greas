#!/usr/bin/env bash
# Builds every host configuration and diffs it against the Blender reference.
set -uo pipefail
: "${BLENDER:?}"; WORK="${WORK:-$PWD/host_build}"; HERE="$(cd "$(dirname "$0")" && pwd)"
rc=0
for c in blender_ref pg_before_math pg_signed_char pg_l1_scalar; do
  rm -rf "$WORK/$c"; CONFIG=$c OUT="$WORK/$c" "$HERE/build_l1_host.sh" >"$WORK.$c.build.log" 2>&1 || { echo "BUILD FAIL $c"; rc=1; continue; }
  "$WORK/$c/l1_parity_harness" > "$WORK/$c.out" || { echo "RUN FAIL $c"; rc=1; }
done
for c in pg_before_math pg_signed_char pg_l1_scalar; do
  if cmp -s "$WORK/blender_ref.out" "$WORK/$c.out"; then echo "$c: IDENTICAL to blender_ref"
  else echo "$c: DIFFERS from blender_ref ($(diff "$WORK/blender_ref.out" "$WORK/$c.out" | grep -c '^<') lines)"; fi
done
exit $rc
