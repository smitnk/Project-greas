#!/usr/bin/env python3
"""Apply the L1 BLI changes to a checkout of feature/project-grease-ui-real-integration.

Edits are exact-string replacements against the files as they exist on that branch.
Every edit asserts that its anchor exists exactly once, so nothing is applied to a
diverged tree. Run from the repository root:  python3 tools/apply_l1_changes.py
Also copies third_party/sse2neon (v1.6.0) from this package if --package is given.
"""
import argparse, pathlib, shutil, sys

MANIFEST = "tools/android_gp_source_manifest.txt"
CMAKE = "android/app/src/main/cpp/CMakeLists.txt"
BL = "third_party/blender"

WRAPPERS_OLD = (
    "C|native/blender_gp/android_blender_math_vector_compat.c\n"
    "C|native/blender_gp/android_blender_math_matrix_compat.c\n"
    "C|native/blender_gp/android_blender_math_rotation_compat.c\n"
)
WRAPPERS_NEW = (
    f"C|{BL}/source/blender/blenlib/intern/math_vector.c\n"
    f"C|{BL}/source/blender/blenlib/intern/math_matrix.c\n"
    f"C|{BL}/source/blender/blenlib/intern/math_rotation.c\n"
    f"C|{BL}/source/blender/blenlib/intern/math_base.c\n"
    f"C|{BL}/source/blender/blenlib/intern/math_color.c\n"
    f"C|{BL}/source/blender/blenlib/intern/math_solvers.c\n"
)
ADD_AFTER_ANCHOR = f"C|{BL}/source/blender/blenlib/intern/BLI_heap.c\n"
ADD_LINES = (
    f"C|{BL}/source/blender/blenlib/intern/BLI_heap_simple.c\n"
    f"C|{BL}/source/blender/blenlib/intern/BLI_kdopbvh.c\n"
    f"C|{BL}/source/blender/blenlib/intern/DLRB_tree.c\n"
    f"C|{BL}/source/blender/blenlib/intern/BLI_dynstr.c\n"
    f"C|{BL}/source/blender/blenlib/intern/gsqueue.c\n"
    f"C|{BL}/source/blender/blenlib/intern/time.c\n"
    f"C|{BL}/extern/wcwidth/wcwidth.c\n"
    f"CXX|{BL}/source/blender/blenlib/intern/task_pool.cc\n"
    f"CXX|{BL}/source/blender/blenlib/intern/task_range.cc\n"
    f"CXX|{BL}/source/blender/blenlib/intern/task_scheduler.cc\n"
    f"CXX|{BL}/source/blender/blenlib/intern/threads.cc\n"
    f"CXX|{BL}/intern/eigen/intern/matrix.cc\n"
    f"CXX|{BL}/intern/eigen/intern/svd.cc\n"
    f"CXX|{BL}/intern/eigen/intern/eigenvalues.cc\n"
)

CMAKE_STANDALONE_OLD = '''set_source_files_properties(
    "${BLENDER_SOURCE_DIR}/source/blender/blenlib/intern/math_matrix.c"
    "${BLENDER_SOURCE_DIR}/source/blender/blenlib/intern/math_vector.c"
    "${BLENDER_SOURCE_DIR}/source/blender/blenlib/intern/math_rotation.c"
    PROPERTIES COMPILE_DEFINITIONS MATH_STANDALONE
)
'''
CMAKE_STANDALONE_NEW = '''# L1: MATH_STANDALONE removed. Blender 3.6.23 builds math_matrix.c with the
# Eigen C API (EIG_invert_m4_m4); MATH_STANDALONE switched to a different inverse.
'''
CMAKE_INC_ANCHOR = '''    "${BLENDER_SOURCE_DIR}/intern/clog"
'''
CMAKE_INC_NEW = '''    "${BLENDER_SOURCE_DIR}/intern/clog"
    "${BLENDER_SOURCE_DIR}/intern/eigen"
    "${BLENDER_SOURCE_DIR}/extern/Eigen3"
'''
CMAKE_OPTS_OLD = '''target_compile_options(projectgrease_jni PRIVATE
    -fPIC
    -ffunction-sections
    -fdata-sections
    -fvisibility=hidden
)
'''
CMAKE_OPTS_NEW = '''target_compile_options(projectgrease_jni PRIVATE
    -fPIC
    -ffunction-sections
    -fdata-sections
    -fvisibility=hidden
    # Blender 3.6.23 platform_unix.cmake (Clang): PLATFORM_CFLAGS.
    -funsigned-char
    -fno-strict-aliasing
    -ffp-contract=off
)

# Blender 3.6.23 SIMD configuration (top-level CMakeLists.txt, WITH_CPU_SIMD):
# NEON builds use sse2neon (v1.6.0, versions.cmake) and define WITH_SSE2NEON,
# which makes BLI_simd.h define BLI_HAVE_SSE2 with Blender's PRECISE settings.
if(ANDROID_ABI STREQUAL "arm64-v8a")
    target_compile_definitions(projectgrease_jni PRIVATE WITH_SSE2NEON)
    target_include_directories(projectgrease_jni SYSTEM PRIVATE
        "${PROJECT_GREASE_ROOT}/third_party/sse2neon")
endif()
'''

def replace_once(text, old, new, what):
    n = text.count(old)
    if n != 1:
        sys.exit(f"ERROR: anchor for {what} found {n} times; tree differs from the inspected branch")
    return text.replace(old, new)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--package", help="path to the unpacked L1 package (copies third_party/sse2neon)")
    a = ap.parse_args()
    root = pathlib.Path.cwd()
    m = (root / MANIFEST).read_text()
    m = replace_once(m, WRAPPERS_OLD, WRAPPERS_NEW, "math wrapper lines")
    m = replace_once(m, ADD_AFTER_ANCHOR, ADD_AFTER_ANCHOR + ADD_LINES, "BLI_heap.c line")
    (root / MANIFEST).write_text(m)
    c = (root / CMAKE).read_text()
    c = replace_once(c, CMAKE_STANDALONE_OLD, CMAKE_STANDALONE_NEW, "MATH_STANDALONE block")
    c = replace_once(c, CMAKE_INC_ANCHOR, CMAKE_INC_NEW, "include dirs")
    c = replace_once(c, CMAKE_OPTS_OLD, CMAKE_OPTS_NEW, "compile options")
    (root / CMAKE).write_text(c)
    if a.package:
        src = pathlib.Path(a.package) / "third_party" / "sse2neon"
        shutil.copytree(src, root / "third_party" / "sse2neon", dirs_exist_ok=True)
    print("L1 changes applied. The three android_blender_math_*_compat.c files are now unused.")

if __name__ == "__main__":
    main()
